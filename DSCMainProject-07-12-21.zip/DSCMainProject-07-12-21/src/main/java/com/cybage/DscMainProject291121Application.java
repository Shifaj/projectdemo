package com.cybage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DscMainProject291121Application {

	public static void main(String[] args) {
		SpringApplication.run(DscMainProject291121Application.class, args);
	}

}
