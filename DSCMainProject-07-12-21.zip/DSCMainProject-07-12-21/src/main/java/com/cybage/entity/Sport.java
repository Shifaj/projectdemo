package com.cybage.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="sport")

public class Sport {
	
			@Id //pK
			@GeneratedValue(strategy=GenerationType.IDENTITY) //pk generation statergy
			private long sportId;
			
			@Column(unique=true)
			@NotNull
			private String sportName;
			
			@Column(name="fees")
			@NotNull
			private String fees;
					
//			@ManyToOne
//			@JoinColumn(name="userId")
//			private User userId;
		
			
		}


