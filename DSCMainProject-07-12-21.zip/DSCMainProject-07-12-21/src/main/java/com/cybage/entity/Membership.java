package com.cybage.entity;
import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name="membership")
public class Membership {
	
	public Membership( Date startDate, Date endDate, @NotNull String isActive,
			Sport sportId, Offer offerId, User id) {
		super();
		
		this.startDate = startDate;
		this.endDate = endDate;
		this.isActive = isActive;
		this.sportId = sportId;
		this.offerId = offerId;
		this.id = id;
	}

	public Membership() {
		super();
	}

					@Id //pK
					@GeneratedValue(strategy=GenerationType.IDENTITY) //pk generation statergy
					private long memberId;
			
					@Column(name="startDate")
					@CreationTimestamp
					private Date startDate ;
					
					@Column(name="endDate")
					private Date endDate ;
				
							
					@Column(columnDefinition="varchar(255) default 'TRUE'")
					@NotNull
					private String isActive;
					
					@OneToOne
					@JoinColumn(name="sportId")
					private Sport sportId;
					
					@OneToOne
					@JoinColumn(name="offerId")
					private Offer offerId;
					
					@ManyToOne  //check it once
					@JoinColumn(name="id")
					private User id;

					public long getMemberId() {
						return memberId;
					}

					public void setMemberId(long memberId) {
						this.memberId = memberId;
					}

					public Date getStartDate() {
						return startDate;
					}

					public void setStartDate(Date startDate) {
						this.startDate = startDate;
					}

					public Date getEndDate() {
						return endDate;
					}

					public void setEndDate(Date endDate) {
						this.endDate = endDate;
					}

					public String getIsActive() {
						return isActive;
					}

					public void setIsActive(String isActive) {
						this.isActive = isActive;
					}

					public Sport getSportId() {
						return sportId;
					}

					public void setSportId(Sport sportId) {
						this.sportId = sportId;
					}

					public Offer getOfferId() {
						return offerId;
					}

					public void setOfferId(Offer offerId) {
						this.offerId = offerId;
					}

					public User getId() {
						return id;
					}

					public void setId(User id) {
						this.id = id;
					}

				
					
					
					
					
				}


