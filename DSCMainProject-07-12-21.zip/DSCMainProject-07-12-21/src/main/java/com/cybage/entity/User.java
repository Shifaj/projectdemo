package com.cybage.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="user")



public class User {

		@Id //pK
		@GeneratedValue(strategy=GenerationType.IDENTITY) //pk generation statergy
		private int id;
		
		@Column(name="first_name")
		@NotNull
		private String firstName;
		
		@Column(name="last_name")
		@NotNull
		private String lastName;
		
		@Column(unique=true)
		@NotNull
		
		private String email;

		
		@Column(name="password")
		@NotNull
		private String password;
		
		@Column(name="gender")
		@NotNull
		private String gender;
		
		
		@Enumerated(EnumType.STRING)
		@Column(name = "role", length = 20)
		private Role role;
		
		@Enumerated(EnumType.STRING)
		@Column(name="status",columnDefinition="varchar(255) default 'UNLOCK'")
		private Status status;
		
		@Enumerated(EnumType.STRING)
		@Column(name="enrolledStatus",columnDefinition="varchar(255) default 'PENDING'")
		private EnrolledStatus enrolledStatus;
		
		
		
		@Column(name="loginAttempt")
		private int loginAttempt;



		public User(@NotNull String firstName) {
			super();
			this.firstName = firstName;
		}



		public int getId() {
			return id;
		}



		public void setId(int id) {
			this.id = id;
		}



		public String getFirstName() {
			return firstName;
		}



		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}



		public String getLastName() {
			return lastName;
		}



		public void setLastName(String lastName) {
			this.lastName = lastName;
		}



		public String getEmail() {
			return email;
		}



		public void setEmail(String email) {
			this.email = email;
		}



		public String getPassword() {
			return password;
		}



		public void setPassword(String password) {
			this.password = password;
		}



		public String getGender() {
			return gender;
		}



		public void setGender(String gender) {
			this.gender = gender;
		}



		public Role getRole() {
			return role;
		}



		public void setRole(Role role) {
			this.role = role;
		}



		public Status getStatus() {
			return status;
		}



		public void setStatus(Status status) {
			this.status = status;
		}



		public EnrolledStatus getEnrolledStatus() {
			return enrolledStatus;
		}



		public void setEnrolledStatus(EnrolledStatus enrolledStatus) {
			this.enrolledStatus = enrolledStatus;
		}



		public int getLoginAttempt() {
			return loginAttempt;
		}



		public void setLoginAttempt(int loginAttempt) {
			this.loginAttempt = loginAttempt;
		}

		
		
		
		
		
//		public long getUserId() {
//			return userId;
//		}
//
//		public void setUserId(long userId) {
//			this.userId = userId;
//		}
//
//		public String getFirstName() {
//			return firstName;
//		}
//
//		public void setFirstName(String firstName) {
//			this.firstName = firstName;
//		}
//
//		public String getLastName() {
//			return lastName;
//		}
//
//		public void setLastName(String lastName) {
//			this.lastName = lastName;
//		}
//
//		public String getEmail() {
//			return email;
//		}
//
//		public void setEmail(String email) {
//			this.email = email;
//		}
//
//		public String getPassword() {
//			return password;
//		}
//
//		public void setPassword(String password) {
//			this.password = password;
//		}
//
//		public String getGender() {
//			return gender;
//		}
//
//		public void setGender(String gender) {
//			this.gender = gender;
//		}
//
//		public String getRole() {
//			return role;
//		}
//
//		public void setRole(String role) {
//			this.role = role;
//		}
//
//		public String getIsActive() {
//			return isActive;
//		}
//
//		public void setIsActive(String isActive) {
//			this.isActive = isActive;
//		}
//
//		public int getLoginAttempt() {
//			return loginAttempt;
//		}
//
//		public void setLoginAttempt(int loginAttempt) {
//			this.loginAttempt = loginAttempt;
//		} 
//		
//		
//		
		
		
	}


