package com.cybage.dto;

import java.sql.Date;

public class MembershipDTO {

	private Date startDate ;
	
	private Date endDate ;

	private String isActive;
	
	private long sportId;
	
	private long offerId;
	
	private int id;

	public MembershipDTO(Date startDate, Date endDate, String isActive, long sportId, long offerId,
			int id) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.isActive = isActive;
		this.sportId = sportId;
		this.offerId = offerId;
		this.id = id;
	}

	public MembershipDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public long getSportId() {
		return sportId;
	}

	public void setSportId(long sportId) {
		this.sportId = sportId;
	}

	public long getOfferId() {
		return offerId;
	}

	public void setOfferId(long offerId) {
		this.offerId = offerId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

		
}
