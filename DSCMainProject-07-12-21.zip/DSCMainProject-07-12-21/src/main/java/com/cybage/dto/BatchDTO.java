package com.cybage.dto;

import java.sql.Time;

public class BatchDTO {
	 
	 private String batchName; 
	 private String batchDescription;
	 private Time startTime;
	 private Time endTime; 
	 private int batchSize;
	 private long sportId;
	public BatchDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BatchDTO(String batchName, String batchDescription, Time startTime, Time endTime, int batchSize,
			long sportId) {
		super();
		this.batchName = batchName;
		this.batchDescription = batchDescription;
		this.startTime = startTime;
		this.endTime = endTime;
		this.batchSize = batchSize;
		this.sportId = sportId;
	}
	public String getBatchName() {
		return batchName;
	}
	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}
	public String getBatchDescription() {
		return batchDescription;
	}
	public void setBatchDescription(String batchDescription) {
		this.batchDescription = batchDescription;
	}
	public Time getStartTime() {
		return startTime;
	}
	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}
	public Time getEndTime() {
		return endTime;
	}
	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}
	public int getBatchSize() {
		return batchSize;
	}
	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}
	public long getSportId() {
		return sportId;
	}
	public void setSportId(long sportId) {
		this.sportId = sportId;
	}
	@Override
	public String toString() {
		return "BatchDTO [batchName=" + batchName + ", batchDescription=" + batchDescription + ", startTime="
				+ startTime + ", endTime=" + endTime + ", batchSize=" + batchSize + ", sportId=" + sportId + "]";
	}
	 
}
