package com.cybage.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.entity.Membership;
import com.cybage.exception.ResourceNotFoundException;
import com.cybage.repository.MembershipRepository;
import com.cybage.service.MembershipService;

@Service
public class MembershipServiceImpl implements MembershipService {

	@Autowired
	private MembershipRepository membershipRepository;

	@Override
	public Membership saveMembership(Membership membership) {

		return membershipRepository.save(membership);
	}

	@Override
	public List<Membership> getMembership() {

		return membershipRepository.findAll();
	}

	@Override
	public Membership getMembershipById(long id) {

		// return repo.findById(id).orElse(null);

		// or

		Optional<Membership> e = membershipRepository.findById(id);
		if (e.isPresent()) {
			return e.get();
		} else {
			throw new ResourceNotFoundException("Membership", "id", id);
		}
		// u can use lamda expression also

//					return userRepository.findById(id).orElseThrow(() -> 
//					new ResourceNotFoundException("Employee", "id", id));
//					
	}

	@Override
	public Membership updateMembership(Membership membership, long id) {
		// first we need to check the user with given id is exist in db or not

		Membership existingMembership = membershipRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Membership", "id", id));

		existingMembership.setEndDate(membership.getEndDate());
		existingMembership.setIsActive(membership.getIsActive());
//		existingMembership.setStartDate(membership.getStartDate());

		// save existing emp to db

		return membershipRepository.save(existingMembership);

	}

	@Override
	public void deleteMembership(long membershipId) {

		// if id not existed we need to throw exception check whether emp exist in db or
		// not

		membershipRepository.findById(membershipId)
				.orElseThrow(() -> new ResourceNotFoundException("Membership", "membershipId", membershipId));
		membershipRepository.deleteById(membershipId);

	}

	

}
