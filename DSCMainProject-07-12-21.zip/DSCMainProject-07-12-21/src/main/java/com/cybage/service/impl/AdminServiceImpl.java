package com.cybage.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.cybage.entity.EnrolledStatus;
import com.cybage.entity.Role;
import com.cybage.entity.Status;
import com.cybage.entity.User;
import com.cybage.exception.ResourceNotFoundException;
import com.cybage.repository.AdminRepository;
import com.cybage.repository.UserRepository;
import com.cybage.service.IAdminService;
//import com.example.repository.RegistrationRepository;

@Service
public class AdminServiceImpl implements IAdminService {
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
private JavaMailSender javaMailSender;


//login registration user***************************************************

public User saveUser(User user) {
	user.setRole(Role.USER);//enum
	user.setStatus(Status.UNLOCK);
	return adminRepository.save(user);
}

public User fetchUserByEmail(String email) {
	return adminRepository.findByEmail(email);
}

//lock******************************************************************
//public ResponseEntity<?> fetchUserByEmailAndPassword(String email, String password) {
//	
//	User userObj=userRepository.findByEmailAndPassword(email,password);
//	
//	if(userObj==null) {
//		User user=userRepository.findByEmail(email);
//		if(user.getLoginAttempt()<=1) {
//			int counter=user.getLoginAttempt();
//			counter++;
//			user.setLoginAttempt(counter);
//			userRepository.save(user);		
//		}		
//		
//		else{
//			System.out.println("INSiDE");
//			user.setStatus(Status.LOCK);
//			userRepository.save(user);
//
//			
//		}
//	}
//	else if(userObj.getStatus().equals(Status.UNLOCK ) ) {
//		userObj.setLoginAttempt(0);
//		userObj=userRepository.save(userObj);
//		return ResponseEntity.ok(userObj);
//	}
//	return ResponseEntity.ok("Account is locked");
//	
//	
//}


public User fetchUserByEmailAndPassword(String email, String password) {
	
	User userObj=userRepository.findByEmailAndPassword(email,password);
	
	if(userObj==null) {
		User user=userRepository.findByEmail(email);
		if(user.getLoginAttempt()<=1) {
			int counter=user.getLoginAttempt();
			counter++;
			user.setLoginAttempt(counter);
			userRepository.save(user);		
		}		
		
		else{
			System.out.println("INSiDE");
			user.setStatus(Status.LOCK);
			userRepository.save(user);

			
		}
	}
	else if(userObj.getStatus().equals(Status.UNLOCK ) ) {
		userObj.setLoginAttempt(0);
		userObj=userRepository.save(userObj);
		return userObj;
	}
	return null;
	
	
}

public List<User> getBlockList(){
	return userRepository.findAllByStatus(Status.LOCK);
}
//unlockk***********************************************************************

//public String unBlockAccount(int id) {
//	User user=userRepository.findById(id).get();
//	user.setStatus(Status.UNLOCK);
//	user.setLoginAttempt(0);
//	userRepository.save(user);
//	return "UNLOCKED SUCCESSFULLY.";
//}


public User unBlockAccount(User user,int id) {
	User existingUser=userRepository.findById(id).orElseThrow(()->
	new ResourceNotFoundException("User","id",id));
	existingUser.setStatus(Status.UNLOCK);
	existingUser.setLoginAttempt(0);
	
	return userRepository.save(existingUser);
	
}



public List<User> findLockUsers() {
	List<User> user=adminRepository.findLockUsers();
	System.out.println(user);
	return user;

}


//email*************************************************************
	public User addUser(User user) {
		System.out.println("....................");
		
		User existedUser=userRepository.findByEmail(user.getEmail());
		System.out.println(existedUser);
		if(existedUser!=null) {
			System.out.println("Manager with given email is already registered..");
			return user;
			
		}
		else{
			
			user.setRole(Role.MANAGER);
			user.setStatus(Status.UNLOCK);
			user.setEnrolledStatus(EnrolledStatus.APPROVED);

			User user1=userRepository.save(user);
			System.out.println(user1);
//			Properties prop= new Properties();
			StringBuilder text= new StringBuilder();
			SimpleMailMessage msg= new SimpleMailMessage();
			
			msg.setTo(user.getEmail());
			msg.setFrom("Trng1@evolvingsols.com");
			msg.setSubject("Login Credentials of "+user.getFirstName()+" "+user.getLastName());
			
			text.append("Hello User, \n");
			text.append("We received your signup request,below are your credentials for login to DSC . \n"
					+"UserName : "+user.getFirstName()+" "+ user.getLastName()+ "\n"
					+"Email ID : "+user.getEmail()+"\n"
					+"Password : "+user.getPassword()+"\n\n");
			text.append("Regards,\n"+"Admin \nDeccan Sports club \n India\n");
			text.append("THANK YOU");
			msg.setText(text.toString());
			javaMailSender.send(msg);
			System.out.println("Successfuly Added");
			return user;
			
		}
			
					
	}
	
	
	
	
	
	

	//crud methodss****************************************************
	public List<User> getUser() {
		
		return adminRepository.findAll();	}

public List<User> getManager() {
		
		return adminRepository.findManagerList();	}

	public User getUserById(int id) {
		
		//return repo.findById(id).orElse(null);
		
		//or 
		
		Optional<User> e= adminRepository.findById(id);
		if(e.isPresent()) {
			return e.get();
		}
		else {
			throw new ResourceNotFoundException("User", "id", id);
		}
		//u can use lamda expression also
		
//		return adminRepository.findById(id).orElseThrow(() -> 
//		new ResourceNotFoundException("Employee", "id", id));
//		
	}

	
	public User updateUser(User user, int id) {
		//first we need to check the user with given id is exist in db or not
		
		User existingUser= adminRepository.findById(id).orElseThrow(() -> 
		new ResourceNotFoundException("User", "id", id));
		
		existingUser.setFirstName(user.getFirstName());
		existingUser.setLastName(user.getLastName());
		
		existingUser.setPassword(user.getPassword());
		existingUser.setGender(user.getGender());
		existingUser.setRole(user.getRole());
		existingUser.setStatus(user.getStatus());
		
		
		//save existing emp to db
		
		return adminRepository.save(existingUser);
		
	}

	
	public void deleteUser(int userId) {
		
		//if id not existed we need to throw exception check whether emp exist in db or not
		
		adminRepository.findById(userId).orElseThrow(() -> 
			new ResourceNotFoundException("User", "userId", userId));
		adminRepository.deleteById(userId);
		
	}
	
	
	
	//**********************otp
	public String findEmailByUsername(String key) {

		User user = userRepository.findByEmail(key);
		if (user != null) {
			return user.getEmail();
		}

		return null;

	}

	
}
