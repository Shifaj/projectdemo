package com.cybage.service;

import java.util.List;

import com.cybage.entity.Batch;

public interface BatchService {
	Batch saveBatch(Batch batch);

	List<Batch> getBatch();
	Batch getBatchById(long batchId);
	Batch updateBatch(Batch batch,long batchId);
	void deleteBatch(long batchId);
	//for testcases return type must be something boolean,string 
	}


