package com.cybage.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.entity.Offer;
import com.cybage.exception.ResourceNotFoundException;
import com.cybage.repository.OfferRepository;
import com.cybage.service.OfferService;




	@Service
	public class OfferServiceImpl implements OfferService{

			@Autowired
				private OfferRepository offerRepository;

				@Override
				public Offer saveOffer(Offer offer) {
					
					return offerRepository.save(offer);
				}

				@Override
				public List<Offer> getOffer() {
					
					return offerRepository.findAll();	}

				@Override
				public Offer getOfferById(long id) {
					
					//return repo.findById(id).orElse(null);
					
					//or 
					
					Optional<Offer> e= offerRepository.findById(id);
					if(e.isPresent()) {
						return e.get();
					}
					else {
						throw new ResourceNotFoundException("Offer", "id", id);
					}
					//u can use lamda expression also
					
//					return userRepository.findById(id).orElseThrow(() -> 
//					new ResourceNotFoundException("Employee", "id", id));
//					
				}

				@Override
				public Offer updateOffer(Offer offer, long id) {
					//first we need to check the user with given id is exist in db or not
					
					Offer existingOffer= offerRepository.findById(id).orElseThrow(() -> 
					new ResourceNotFoundException("Offer", "id", id));
					
				
				
					existingOffer.setOfferName(offer.getOfferName());
					existingOffer.setOfferDescription(offer.getOfferDescription());
					existingOffer.setDiscount(offer.getDiscount());
					
					
					//save existing emp to db
					
					return offerRepository.save(existingOffer);
					
				}

				@Override
				public void deleteOffer(long offerId) {
					
					//if id not existed we need to throw exception check whether emp exist in db or not
					
					offerRepository.findById(offerId).orElseThrow(() -> 
						new ResourceNotFoundException("Offer", "offerId", offerId));
					offerRepository.deleteById(offerId);
					
				}
				

//				@Override
				public void addLike(long offerId) {
					Optional<Offer> findById = offerRepository.findById(offerId);
					Offer offer = findById.orElseThrow(()-> new ResourceNotFoundException("Offer not found!!"));
					int count = offer.getLikes();
					count++;
					offer.setLikes(count);
					offerRepository.save(offer);
				}
				
//				@Override
				public void removeLike(long offerId) {
					Optional<Offer> findById = offerRepository.findById(offerId);
					Offer offer = findById.orElseThrow(()-> new ResourceNotFoundException("Offer not found!!"));
					int count = offer.getLikes();
					count--;
					offer.setLikes(count);
					offerRepository.save(offer);
				}

				
			}

