package com.cybage.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.entity.Comment;
import com.cybage.repository.CommentRepository;
import com.cybage.service.CommentService;

@Service
public class CommentServiceImpl implements CommentService {

	@Autowired
	private CommentRepository commentRepository;
	
	@Override
	public Comment addComment(Comment comment) {
		
		return commentRepository.save(comment);
	}

	@Override
	public List<Comment> getComments() {
		
		return commentRepository.findAll();
	}

	@Override
	public Comment getCommentById(long commentId) {
		
		return commentRepository.findById(commentId).get();
	}

}
