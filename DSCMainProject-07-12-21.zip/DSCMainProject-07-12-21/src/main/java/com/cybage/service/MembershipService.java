package com.cybage.service;

import java.util.List;

import com.cybage.entity.Membership;

public interface MembershipService {

	Membership saveMembership(Membership membership);

	List<Membership> getMembership();
	Membership getMembershipById(long membershipId);
	Membership updateMembership(Membership membership,long membershipId);
	void deleteMembership(long membershipId);

	
}
