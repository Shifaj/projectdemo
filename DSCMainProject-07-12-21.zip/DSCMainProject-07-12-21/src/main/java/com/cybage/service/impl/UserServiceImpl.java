package com.cybage.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.exception.ResourceNotFoundException;
import com.cybage.repository.UserRepository;
import com.cybage.service.UserService;
import com.cybage.entity.EnrolledStatus;
import com.cybage.entity.User;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
		private UserRepository userRepository;

		@Override
		public User saveUser(User user) {
			
			return userRepository.save(user);
		}

		@Override
		public List<User> getUser() {
			
			return userRepository.findEndUser() ;	}

		@Override
		public User getUserById(int id) {
			
			//return repo.findById(id).orElse(null);
			
			//or 
			
			Optional<User> e= userRepository.findById(id);
			if(e.isPresent()) {
				return e.get();
			}
			else {
				throw new ResourceNotFoundException("User", "id", id);
			}
			//u can use lamda expression also
			
//			return userRepository.findById(id).orElseThrow(() -> 
//			new ResourceNotFoundException("Employee", "id", id));
//			
		}

		@Override
		public User updateUser(User user, int id) {
			//first we need to check the user with given id is exist in db or not
			
			User existingUser= userRepository.findById(id).orElseThrow(() -> 
			new ResourceNotFoundException("User", "id", id));
			
			existingUser.setFirstName(user.getFirstName());
			existingUser.setLastName(user.getLastName());
			
			existingUser.setPassword(user.getPassword());
			existingUser.setGender(user.getGender());
			existingUser.setRole(user.getRole());
			existingUser.setStatus(user.getStatus());
			existingUser.setEnrolledStatus(user.getEnrolledStatus());
			
			//save existing emp to db
			
			return userRepository.save(existingUser);
			
		}

		@Override
		public void deleteUser(int userId) {
			
			//if id not existed we need to throw exception check whether emp exist in db or not
			
			userRepository.findById(userId).orElseThrow(() -> 
				new ResourceNotFoundException("User", "userId", userId));
			userRepository.deleteById(userId);
			
		}

		@Override
		public User approveUser(User user, int id) {
			//first we need to check the user with given id is exist in db or not
			
			User existingUser= userRepository.findById(id).orElseThrow(() -> 
			new ResourceNotFoundException("User", "id", id));
			
			existingUser.setEnrolledStatus(EnrolledStatus.APPROVED);
			return userRepository.save(existingUser);
			
		}
		
		@Override
		public User rejectUser(User user, int id) {
			//first we need to check the user with given id is exist in db or not
			
			User existingUser= userRepository.findById(id).orElseThrow(() -> 
			new ResourceNotFoundException("User", "id", id));
			
			existingUser.setEnrolledStatus(EnrolledStatus.REJECTED);
			User upadatedUser=userRepository.save(existingUser);
			return userRepository.save(upadatedUser);
			
		}

		
	}


