package com.cybage.service;

import java.util.List;

import com.cybage.entity.Offer;

public interface OfferService {
	Offer saveOffer(Offer offer);

	List<Offer> getOffer();
	Offer getOfferById(long offerId);
	Offer updateOffer(Offer offer,long offerId);
	void deleteOffer(long offerId);
}
