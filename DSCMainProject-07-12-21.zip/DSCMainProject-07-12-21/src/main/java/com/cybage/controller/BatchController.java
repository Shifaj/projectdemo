package com.cybage.controller;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.dto.BatchDTO;
import com.cybage.entity.Batch;
import com.cybage.entity.Sport;
import com.cybage.exception.ResourceNotFoundException;
import com.cybage.service.BatchService;
import com.cybage.service.SportService;
import com.cybage.service.impl.LogsServiceImpl;
@RestController @CrossOrigin(origins="http://localhost:4200")
//@RequestMapping("admin")
public class BatchController {
	
	Logger logger=LogManager.getLogger("BatchController.Class");
	
	
			@Autowired
				public BatchService batchService;

			/*@NotNull String batchName, @NotNull Time startTime, @NotNull Time endTime,
						@NotNull int batchSize, @NotNull String batchDescription, String isActive, Sport sportId*/
			
			@Autowired
				private SportService sportService; 
				//add batch
			@Autowired
			private LogsServiceImpl logService;
				@PostMapping("/addBatches")
				public ResponseEntity<Batch> saveBatch(@RequestBody BatchDTO batch){
					System.out.println(batch.getSportId());
					Sport sport = sportService.getSportById(batch.getSportId());
					Batch batch2 = new Batch(batch.getBatchName(), batch.getStartTime(), batch.getEndTime(), batch.getBatchSize(), batch.getBatchDescription(), "TRUE", sport);
					return new ResponseEntity<Batch>(batchService.saveBatch(batch2),HttpStatus.CREATED );
				}
				
				//get employees
				@GetMapping("/batch")
				public List<Batch> getBatch(){
					logger.debug("In get all batches");
					List<Batch> batches = batchService.getBatch();
					if(batches.size()==0) {
						throw new ResourceNotFoundException("Doesnt have any batch");
					}else {
					return batchService.getBatch();
					}
				}
				
				//get batch by id
				@GetMapping("/batch/{batchId}")
				public ResponseEntity<Batch> getBatchById(@PathVariable("batchId") long id)
				{
					return new ResponseEntity<Batch>(batchService.getBatchById(id),HttpStatus.OK);
				}
				
				//update
				@PutMapping("updateBatch/{batchId}")
				public ResponseEntity<Batch> updateBatch(@PathVariable("batchId") long batchId,
															@RequestBody BatchDTO batch)
				{
					//return new ResponseEntity<Batch>(batchService.updateBatch(batch, batchId), HttpStatus.OK);
					Sport sport = sportService.getSportById(batch.getSportId());
					Batch batch2 = new Batch(batch.getBatchName(), batch.getStartTime(), batch.getEndTime(), batch.getBatchSize(), batch.getBatchDescription(), "TRUE", sport);
					return new ResponseEntity<Batch>(batchService.updateBatch(batch2, batchId),HttpStatus.CREATED );
					
				}
				
				//delete
				@DeleteMapping("/deleteBatch/{batchId}")
				public ResponseEntity<String> deleteBatch(@PathVariable("batchId")long batchId){
					
					//delete batch from db
					batchService.deleteBatch(batchId);
					return new ResponseEntity<String>("Batch deleted successfully!!",HttpStatus.OK);
					
					
				}
				
			}

			





