package com.cybage.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import java.util.Base64;
import com.cybage.entity.User;
import com.cybage.service.IAdminService;
import com.cybage.service.impl.AdminServiceImpl;
@RestController 
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("admin")
public class AdminController {
			
		@Autowired
			private AdminServiceImpl adminService;
	
//		private BCryptPasswordEncoder bCryptPasswordEncoder;
		//user registration
		@PostMapping("/registerUser")
		@CrossOrigin(origins="http://localhost:4200")
		public User registerUser(@RequestBody User user) throws Exception {
			//to check whether the email id exist or noy
			
			String tempEmail=user.getEmail();// watever user will fill
			if(tempEmail !=null && !"".equals(tempEmail))
			{
				User userobj=adminService.fetchUserByEmail(tempEmail);
				
				if (userobj!=null) {
					throw new Exception("user with "+tempEmail+" is already exist");
				}
			}
//			user.setPassword(this.bCryptPasswordEncoder.encode(user.getPassword()));
			User userObj=null;
			userObj=adminService.saveUser(user);
			return userObj;
			
			
		
		}
		
		///////***********************************login**************************************************
//		@PostMapping("/login")
//		@CrossOrigin(origins="http://localhost:4200")
//		public ResponseEntity<?> loginUser(@RequestBody User user) throws Exception {
//			//if not present wrong credentials
//			
//			String tempEmail=user.getEmail();
//			String tempPass=user.getPassword();
//			ResponseEntity<?> userObj=null;
//			if(tempEmail!=null && tempPass!=null) {
//				//check combination of condition to find user
//				userObj=adminService.fetchUserByEmailAndPassword(tempEmail, tempPass);
//			}
//			if (userObj==null) {
//				throw new Exception("bad credentials");
//			}
//			
//			return ResponseEntity.ok(userObj);
//		}
		@PostMapping("/login")
		@CrossOrigin(origins="http://localhost:4200")
		public User loginUser(@RequestBody User user) throws Exception {
			//if not present wrong credentials
			
			String tempEmail=user.getEmail();
			String tempPass=user.getPassword();
			User userObj=null;
			if(tempEmail!=null && tempPass!=null) {
				//check combination of condition to find user
				userObj=adminService.fetchUserByEmailAndPassword(tempEmail, tempPass);
			}
			if (userObj==null) {
				throw new Exception("bad credentials");
			}
			
			return userObj;
		}
		
		
		//unlcok
		@GetMapping("/getBlockList")
		public ResponseEntity<List<User>> getBlockedAccounts(){
			return ResponseEntity.ok(adminService.getBlockList());
		}
		
//		@PostMapping("/unlock/{id}")
//		public ResponseEntity<?> removeFromBlockList(@PathVariable int id){
//			return ResponseEntity.ok(adminService.unBlockAccount(id));
//			
//		}
		
//		@GetMapping("/unlock/{id}")
//		public ResponseEntity<?> removeFromBlockList(@PathVariable int id){
//			return ResponseEntity.ok(adminService.unBlockAccount(id));
//			
//		}
		
		@GetMapping("/unlock/{id}")
		public ResponseEntity<User> removeFromBlockList(@PathVariable int id){
			return new ResponseEntity<User>(adminService.unBlockAccount(null, id),HttpStatus.OK);
			
		}
		
		@GetMapping("/lockedUserList")
		public List<User> getLockUser(){
			List<User> user= adminService.findLockUsers();
			System.out.println(user);
			return user;
			
		}
		
		
		
		
		
			//add useranager
			@PostMapping("/addUser")
			public ResponseEntity<?> saveUser(@RequestBody User user){
				System.out.println(user);
				return new ResponseEntity<User>(adminService.addUser(user),HttpStatus.OK);
			}
			
			//get employees
			@GetMapping("/user")
			public List<User> getUser(){
				return adminService.getUser();
			}
			
			@GetMapping("/manager")
			public List<User> getManager(){
				return adminService.getManager();
			}
			//get user by id
			@GetMapping("/user/{id}")
			public ResponseEntity<User> getUserById(@PathVariable("id") int id)
			{
				return new ResponseEntity<User>(adminService.getUserById(id),HttpStatus.OK);
			}
			
			//update
			@PutMapping("updateUser/{id}")
			public ResponseEntity<User> updateUser(@PathVariable("id") int userId,
														@RequestBody User user)
			{
				return new ResponseEntity<User>(adminService.updateUser(user, userId), HttpStatus.OK);
				
			}
			
			//delete
			@DeleteMapping("/deleteUser/{id}")
			public ResponseEntity<String> deleteUser(@PathVariable("id")int id){
				
				//delete user from db
				adminService.deleteUser(id);
				return new ResponseEntity<String>("User deleted successfully!!",HttpStatus.OK);
				
				
			}
			
		}

		



