package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.entity.User;
import com.cybage.exception.ResourceNotFoundException;
import com.cybage.repository.UserRepository;
import com.cybage.service.UserService;
@RestController @CrossOrigin(origins="http://localhost:4200")
//@RequestMapping("user")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	public UserService userService;

	//add user
	@PostMapping("/addUser")
	public ResponseEntity<User> saveUser(@RequestBody User user){

		return new ResponseEntity<User>(userService.saveUser(user),HttpStatus.CREATED );
	}

	//get user
	@GetMapping("/allUser")
	public List<User> getUser(){
		return userService.getUser();
	}

	//get user by id
	@GetMapping("/user/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable("userId") int id)
	{
		return new ResponseEntity<User>(userService.getUserById(id),HttpStatus.OK);
	}

	//update
	@PutMapping("updateUser/{userId}")
	public ResponseEntity<User> updateUser(@PathVariable("userId") int userId,
			@RequestBody User user)
	{
		return new ResponseEntity<User>(userService.updateUser(user, userId), HttpStatus.OK);

	}

	@GetMapping("approveUser/{id}")
	public ResponseEntity<User> approveUserById(@PathVariable("id") int id)
	{
		
		return new ResponseEntity<User>(userService.approveUser(null, id),HttpStatus.OK);
	}
	
	@GetMapping("rejectUser/{id}")
	public ResponseEntity<User> rejectUserById(@PathVariable("id") int id)
	{
		return new ResponseEntity<User>(userService.rejectUser(null, id), HttpStatus.OK);

	}

	//delete
	@DeleteMapping("/deleteUser/{userId}")
	public ResponseEntity<String> deleteUser(@PathVariable("userId")int userId){

		//delete user from db
		userService.deleteUser(userId);
		return new ResponseEntity<String>("User deleted successfully!!",HttpStatus.OK);


	}
	
	@PutMapping("/forgotPassword/{email}")
	public ResponseEntity<User> changePassword(@RequestBody User userPassword, @PathVariable String email) {
		User user = userRepository.findByEmail(email);
		if (user != null) {

			user.setPassword(userPassword.getPassword());
			User updatedPassword = userRepository.save(user); // userRepository.save(user);
			return ResponseEntity.ok(updatedPassword); 
		} else
			throw new ResourceNotFoundException("User with" +email+" does not exist.");
	}

}



