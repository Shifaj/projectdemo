package com.cybage.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import com.cybage.DscMainProject291121Application;
import com.cybage.entity.Sport;
import com.cybage.repository.SportRepository;

@RunWith(SpringRunner.class)
@ContextConfiguration
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes =DscMainProject291121Application.class)

class SportServiceImplTest {
@Autowired
SportRepository sportRepository;
	@Test
	void testSaveSport() {
		Sport sport= new Sport("Vollyball", "800");
		assertNotNull(sportRepository.save(sport));
	}

	@Test
	void testGetSport() {
		assertNotNull(sportRepository.findAll());
	}

	@Test
	void testGetSportById() {
		long sportId=1;
		assertNotNull(sportRepository.findById(sportId));
	}



}
