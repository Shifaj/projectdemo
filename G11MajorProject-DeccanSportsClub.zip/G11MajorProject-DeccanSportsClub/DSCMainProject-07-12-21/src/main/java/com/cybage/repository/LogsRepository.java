package com.cybage.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cybage.entity.Logs;
@Repository
public interface LogsRepository extends JpaRepository<Logs, Integer> {

//  @Query(value = "SELECT * FROM Logs WHERE logId = :id", nativeQuery = true)
@Query("SELECT l FROM Logs l WHERE l.user.id = :id")
List<Logs> getLogsById(@Param("id") int id);

@Query("SELECT l FROM Logs l WHERE l.user.firstName = :firstName")
List<Logs> getLogsByFirstName(@Param("firstName") String firstName);
}
