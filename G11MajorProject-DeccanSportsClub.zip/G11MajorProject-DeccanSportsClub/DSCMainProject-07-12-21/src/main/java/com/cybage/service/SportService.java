package com.cybage.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cybage.entity.Sport;

@Service
public interface SportService {
	
		Sport saveSport(Sport sport);

		List<Sport> getSport();
		Sport getSportById(long id);
		Sport updateSport(Sport sport,long id);
		void deleteSport(long id);
		}




