package com.cybage.service.impl;


	import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.cybage.repository.LogsRepository;
import com.cybage.service.ILogsService;
import com.cybage.entity.Logs;

	@Service
	public class LogsServiceImpl implements ILogsService {

	Logger logger = Logger.getLogger("LogsServiceImpl.class");

	@Autowired
	LogsRepository logsRepository;

	@Override
	public List<Logs> getAllLogs() {
	logger.debug("get All logs of" + getClass().getName());
	return logsRepository.findAll();
	}

	@Override
	public void addLog(Logs logs) {
	logsRepository.save(logs);
	}

	@Override
	public List<Logs> getLogsById(int id) {
	logger.debug("get All logs by id" + getClass().getName());
	return logsRepository.getLogsById(id);
	}

	@Override
	public List<Logs> getLogsByFirstName(String firstName) {
	logger.debug("get All logs by name" + getClass().getName());
	return logsRepository.getLogsByFirstName(firstName);
	}
	}
