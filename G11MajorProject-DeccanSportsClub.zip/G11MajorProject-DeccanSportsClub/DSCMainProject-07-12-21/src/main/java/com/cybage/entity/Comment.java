package com.cybage.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="comment")
public class Comment {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY) //pk generation statergy
	private long commentId;
	
	@Column(name="content")
	private String content;
	
	@Column(name="created_at")
	@CreationTimestamp
	private Date createdAt;
	
	@Column(name="id")
	private int id;
	
	@Column(name="OfferId")
	private long OfferId;

	public Comment() {
		super();
	}

	public Comment(long commentId, String content, Date createdAt, int id, long offerId) {
		super();
		this.commentId = commentId;
		this.content = content;
		this.createdAt = createdAt;
		this.id = id;
		this.OfferId = offerId;
	}

	
	public long getCommentId() {
		return commentId;
	}

	public void setCommentId(long commentId) {
		this.commentId = commentId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getOfferId() {
		return OfferId;
	}

	public void setOfferId(long offerId) {
		OfferId = offerId;
	}

	@Override
	public String toString() {
		return "Comment [commentId=" + commentId + ", content=" + content + ", createdAt=" + createdAt + ", id="
				+ id + ", OfferId=" + OfferId + "]";
	}

	
	
	
	
}
