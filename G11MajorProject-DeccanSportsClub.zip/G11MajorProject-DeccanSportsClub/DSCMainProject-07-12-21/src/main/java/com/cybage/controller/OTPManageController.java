package com.cybage.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.otp.OtpService;
@RestController
@CrossOrigin(origins="http://localhost:4200")
public class OTPManageController {

	@Autowired
	private OtpService otpService;
//response produced wiil be convert to json format
	@PostMapping(value = "/generate/{username}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> generateOTP(@PathVariable String username) {
		// Authentication authentication =
		// SecurityContextHolder.getContext().getAuthentication();
		// String username = authentication.getName();

		Map<String, String> response = new HashMap<>(2);

		// check authentication
		if (username == null) {
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		}

		// generate OTP.
		Boolean isGenerated = otpService.generateOtp(username);
		if (!isGenerated) {
			response.put("status", "error");
			response.put("message", "OTP can not be generated.");

			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

		// success message
		response.put("status", "success");
		response.put("message", "OTP successfully generated. Please check your e-mail!");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PostMapping(value = "/validate/{username}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> validateOTP(@RequestBody Map<String, String> otp, @PathVariable String username) {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        String username = authentication.getName();
		int requestedOtp = 0;
		try {
			requestedOtp = Integer.parseInt(otp.get("otp"));
		} catch (NumberFormatException e) {

		}

		System.out.println(username);
		System.out.println(otp);

		Map<String, String> response = new HashMap<>(2);

		// check authentication
		if (username == null) {
			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
		}

		// validate provided OTP.
		Boolean isValid = otpService.validateOTP(username, requestedOtp);
		if (!isValid) {
			response.put("status", "error");
			response.put("message", "OTP is not valid!");

			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

		// success message
		response.put("status", "success");
		response.put("message", "Entered OTP is valid!");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
