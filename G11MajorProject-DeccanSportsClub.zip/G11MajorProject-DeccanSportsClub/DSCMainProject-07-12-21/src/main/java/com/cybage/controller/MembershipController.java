package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.dto.MembershipDTO;
import com.cybage.entity.Membership;
import com.cybage.entity.Offer;
import com.cybage.entity.Sport;
import com.cybage.entity.User;
import com.cybage.service.MembershipService;
import com.cybage.service.OfferService;
import com.cybage.service.SportService;
import com.cybage.service.UserService;

	@RestController
	@CrossOrigin(origins = "http://localhost:4200")
	//@RequestMapping("/membership")
	public class MembershipController {

		@Autowired
		public MembershipService membershipService;
		@Autowired
		private OfferService offerService;
		
		@Autowired
		private SportService sportService;
		
		@Autowired
		private UserService userService;
//		// add membership
//		@PostMapping("/addMembership")
//		public ResponseEntity<Membership> saveMembership(@RequestBody Membership membership) {
//
//			return new ResponseEntity<Membership>(membershipService.saveMembership(membership), HttpStatus.CREATED);
//		}
		
		@PostMapping("/MembershipAdd")
		public ResponseEntity<Membership> saveMembership(@RequestBody MembershipDTO membership){
			
			Sport sport = sportService.getSportById(membership.getSportId());
			System.out.println(sport);
			Offer offer = offerService.getOfferById(membership.getOfferId());
			System.out.println(offer);
			User user = userService.getUserById(membership.getId());
			System.out.println(user);
			Membership newMembership = new Membership(membership.getStartDate(), membership.getEndDate(), "True", sport, offer, user);
			System.out.println("This is new membership" +newMembership);
			return new ResponseEntity<Membership>(membershipService.saveMembership(newMembership), HttpStatus.CREATED);
		}

		// get membership
		@GetMapping("/getMembership")
		public List<Membership> getMembership() {
			return membershipService.getMembership();	
		}

		// get membership by id
		@GetMapping("/getMembership/{membershipId}")
		public ResponseEntity<Membership> getMembershipById(@PathVariable("membershipId") long id) {
			return new ResponseEntity<Membership>(membershipService.getMembershipById(id), HttpStatus.OK);
		}

		// update
		@PutMapping("updateMembership/{membershipId}")
		public ResponseEntity<Membership> updateMembership(@PathVariable("membershipId") long membershipId, @RequestBody Membership membership) {
			return new ResponseEntity<Membership>(membershipService.updateMembership(membership, membershipId), HttpStatus.OK);

		}

		// delete
		@DeleteMapping("/deleteMembership/{membershipId}")
		public ResponseEntity<String> deleteMembership(@PathVariable("membershipId") long membershipId) {

			// delete membership from db
			membershipService.deleteMembership(membershipId);
			return new ResponseEntity<String>("Membership deleted successfully!!", HttpStatus.OK);

		}

	}

