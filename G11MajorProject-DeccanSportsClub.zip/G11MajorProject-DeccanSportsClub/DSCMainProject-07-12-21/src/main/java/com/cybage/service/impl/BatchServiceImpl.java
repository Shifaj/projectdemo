package com.cybage.service.impl;
import java.sql.Time;
import java.util.List;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.exception.ResourceNotFoundException;
import com.cybage.repository.BatchRepository;
import com.cybage.repository.UserRepository;
import com.cybage.service.BatchService;
import com.cybage.entity.Batch;
import com.cybage.entity.Sport;
import com.cybage.entity.User;


	@Service
	public class BatchServiceImpl implements BatchService{

			@Autowired
				private BatchRepository batchRepository;

				@Override
				public Batch saveBatch(Batch batch) {
					
					return batchRepository.save(batch);
				}

				@Override
				public List<Batch> getBatch() {
					
					return batchRepository.findAll();	}

				@Override
				public Batch getBatchById(long id) {
					
					//return repo.findById(id).orElse(null);
					
					//or 
					
					Optional<Batch> e= batchRepository.findById(id);
					if(e.isPresent()) {
						return e.get();
					}
					else {
						throw new ResourceNotFoundException("Batch", "id", id);
					}
					//u can use lamda expression also
					
//					return userRepository.findById(id).orElseThrow(() -> 
//					new ResourceNotFoundException("Employee", "id", id));
//					
				}

				@Override
				public Batch updateBatch(Batch batch, long id) {
					//first we need to check the user with given id is exist in db or not
					
					Batch existingBatch= batchRepository.findById(id).orElseThrow(() -> 
					new ResourceNotFoundException("Batch", "id", id));
					
				
				
					existingBatch.setBatchName(batch.getBatchName());
					existingBatch.setStartTime(batch.getStartTime());
					existingBatch.setEndTime(batch.getEndTime());
					existingBatch.setBatchSize(batch.getBatchSize());
					existingBatch.setBatchDescription(batch.getBatchDescription());
					existingBatch.setIsActive(batch.getIsActive());
					existingBatch.setSportId(batch.getSportId());
					
					//save existing emp to db
					
					return batchRepository.save(existingBatch);
					
				}

				@Override
				public void deleteBatch(long batchId) {
					
					//if id not existed we need to throw exception check whether emp exist in db or not
					
					batchRepository.findById(batchId).orElseThrow(() -> 
						new ResourceNotFoundException("Batch", "batchId", batchId));
					batchRepository.deleteById(batchId);
					
				}

				
			}

