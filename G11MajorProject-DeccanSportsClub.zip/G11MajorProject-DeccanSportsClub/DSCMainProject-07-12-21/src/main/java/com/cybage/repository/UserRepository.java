package com.cybage.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cybage.entity.Status;
import com.cybage.entity.User;
@Repository
public interface UserRepository extends JpaRepository<User,Integer>{


	public User findByEmail(String email);
	public User findByEmailAndPassword(String email,String password);
	public User findByFirstName(String firstName);
	public List<User> findAllByStatus(Status lock);
	@Query(value="select * from user where status='LOCK'" ,nativeQuery=true)
	 public List<User> findLockUsers() ;
	
	@Query(value="select * from user where role='USER'" ,nativeQuery=true)
	 public List<User> findEndUser() ;
	
}
