package com.cybage.controller;
import java.time.LocalDateTime;
import java.util.List;

import javax.validation.Valid;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.entity.Logs;
import com.cybage.entity.Sport;
import com.cybage.entity.User;
import com.cybage.exception.SportsNotFoundException;
import com.cybage.service.ILogsService;
import com.cybage.service.SportService;
import com.cybage.service.UserService;
@RestController @CrossOrigin(origins="http://localhost:4200")
@RequestMapping("admin")
public class SportController {
	
	//Logger logger=LogManager.getLogger("SportController.Class");
	
		@Autowired
			public SportService sportService;
		@Autowired
		public UserService userService;
		@Autowired
		public ILogsService logsService;

			//add sport
			@PostMapping("/addSport")
			public ResponseEntity<Sport> saveSport(@RequestBody Sport sport){
		//	logger.debug("In add sports Controller");
		//		sportService.saveSport(sport);
		//		User user = userService.getUserById(id);
//				String logdesc = user.getEmail() + " : New Sport Added : " + sport.getSportName();
//				String logDate = LocalDateTime.now().toString();
//				Logs logs = new Logs(logdesc, logDate, user);
//				logsService.addLog(logs);

				return new ResponseEntity<Sport>(sportService.saveSport(sport),HttpStatus.CREATED );
			}
			
			//get sports
			@GetMapping("/sport")
			public List<Sport> getSport(){
				//logger.debug("in sport controller");
				
				List<Sport> sport=sportService.getSport();
				if (sport.size() == 0) {
					throw new SportsNotFoundException("No Sports");
				} else {
					return sport;
			}
			}
			
			//get sport by sportId
			@GetMapping("/sport/{sportId}")
			public ResponseEntity<Sport> getSportById(@PathVariable("sportId") long sportId)
			{
				return new ResponseEntity<Sport>(sportService.getSportById(sportId),HttpStatus.OK);
			}
			
			//update
			@PutMapping("updateSport/{sportId}")
			public ResponseEntity<Sport> updateSport(@PathVariable("sportId") long sportId,
														@RequestBody Sport sport)
			{
				
				//logger.debug("In update sports Controller");
//				sportService.updateSport(sport,sportId);

				// logs
//				User user = userService.getUserById(userId);
//				String logdesc = user.getEmail() + " : Sports Updated : " + sport.getSportName();
//				String logDate = LocalDateTime.now().toString();
//				Logs logs = new Logs(logdesc, logDate, user);
//				logsService.addLog(logs);
				return new ResponseEntity<Sport>(sportService.updateSport(sport, sportId), HttpStatus.OK);
				
			}
			
			//delete
			@DeleteMapping("/deleteSport/{sportId}")
			public ResponseEntity<String> deleteSport(@PathVariable("sportId")long sportId){
//				logger.debug("In delete sport Controller");
//				Sport sport = sportService.getSportById(id);
//				
//				sportService.deleteSport(sportId);
//				// logs
//				User user = userService.getUserById(userId);
//				System.out.println("USER" + user);
//				String logdesc = user.getEmail() + " : Sports Deleted : " + sport.getSportName();
//				String logDate = LocalDateTime.now().toString();
//				Logs logs = new Logs(logdesc, logDate, user);
//				logsService.addLog(logs);
				sportService.deleteSport(sportId);
				return new ResponseEntity<String>("deleted sport!!", HttpStatus.OK);
				//delete sport from db
				
				//return new ResponseEntity<String>("Sport deleted successfully!!",HttpStatus.OK);
				
				
			}
			
		}

		



