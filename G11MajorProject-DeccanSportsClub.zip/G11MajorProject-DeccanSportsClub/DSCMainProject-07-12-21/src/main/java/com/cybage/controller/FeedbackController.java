package com.cybage.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@CrossOrigin
public class FeedbackController {
		
	@PostMapping("/add")
	public ResponseEntity<?> addFeedback(@RequestBody Object feedback){
		String url="http://localhost:5400/feedback/add";
		RestTemplate restTemplate=new RestTemplate();
		Boolean postForObject = restTemplate.postForObject(url, feedback, Boolean.class);
		return (postForObject)?new ResponseEntity<>(HttpStatus.OK):new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		
	}
	
	
}
