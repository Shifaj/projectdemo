package com.cybage.dto;

import java.sql.Date;

public class CommentDTO {
private long commentId;
	
	private String content;
	
	private Date createdAt;
	
	private long user;
	
	private long offer;

	public CommentDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommentDTO(String content, Date createdAt, long user, long offer) {
		super();
		this.content = content;
		this.createdAt = createdAt;
		this.user = user;
		this.offer = offer;
	}

	public long getCommentId() {
		return commentId;
	}

	public void setCommentId(long commentId) {
		this.commentId = commentId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public long getUser() {
		return user;
	}

	public void setUser(long user) {
		this.user = user;
	}

	public long getOffer() {
		return offer;
	}

	public void setOffer(long offer) {
		this.offer = offer;
	}

}
