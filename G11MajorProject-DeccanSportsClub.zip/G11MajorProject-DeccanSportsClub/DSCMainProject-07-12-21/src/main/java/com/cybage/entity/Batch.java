package com.cybage.entity;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;


@Data
@Entity
@Table(name="batch")
public class Batch {
	
	public Batch(@NotNull String batchName, @NotNull Time startTime, @NotNull Time endTime,
			@NotNull int batchSize, @NotNull String batchDescription, String isActive, Sport sportId) {
		super();
		this.batchName = batchName;
		this.startTime = startTime;
		this.endTime = endTime;
		this.batchSize = batchSize;
		this.batchDescription = batchDescription;
		this.isActive = isActive;
		this.sportId = sportId;
	}

	public Batch() {
		super();
		// TODO Auto-generated constructor stub
	}

	
				@Id //pK
				@GeneratedValue(strategy=GenerationType.IDENTITY) //pk generation stategy
				private long batchId;
				
				@Column(unique=true)
				@NotNull
				private String batchName;
				
				@Column(name="startTime")
				@NotNull
				private Time startTime ;
				
				@Column(name="endTime")
				@NotNull
				private Time endTime ;
				
				@Column(name="batchSize")
				@NotNull
				private int batchSize;
				
				@Column(name="batchDescription")
				@NotNull
				private String batchDescription;
						
				@Column(columnDefinition="varchar(255) default 'TRUE'")
				private String isActive;
				
				@ManyToOne
				@JoinColumn(name="sportId")
				private Sport sportId;
				
				
				
				public long getBatchId() {
					return batchId;
				}

				public void setBatchId(long batchId) {
					this.batchId = batchId;
				}

				public String getBatchName() {
					return batchName;
				}

				public void setBatchName(String batchName) {
					this.batchName = batchName;
				}

				public Time getStartTime() {
					return startTime;
				}

				public void setStartTime(Time startTime) {
					this.startTime = startTime;
				}

				public Time getEndTime() {
					return endTime;
				}

				public void setEndTime(Time endTime) {
					this.endTime = endTime;
				}

				public int getBatchSize() {
					return batchSize;
				}

				public void setBatchSize(int batchSize) {
					this.batchSize = batchSize;
				}

				public String getBatchDescription() {
					return batchDescription;
				}

				public void setBatchDescription(String batchDescription) {
					this.batchDescription = batchDescription;
				}

				public String getIsActive() {
					return isActive;
				}

				public void setIsActive(String isActive) {
					this.isActive = isActive;
				}

				public Sport getSportId() {
					return sportId;
				}

				public void setSportId(Sport sportId) {
					this.sportId = sportId;
				}
				
				

				
				
			}


