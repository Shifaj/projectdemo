package com.cybage.service.impl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.exception.ResourceNotFoundException;
import com.cybage.repository.SportRepository;
import com.cybage.repository.UserRepository;
import com.cybage.service.SportService;
import com.cybage.entity.Sport;
import com.cybage.entity.User;

@Service
public class SportServiceImpl implements SportService{

		@Autowired
			private SportRepository sportRepository;

			@Override
			public Sport saveSport(Sport sport) {
				
				return sportRepository.save(sport);
			}

			@Override
			public List<Sport> getSport() {
				
				return sportRepository.findAll();	}

			@Override
			public Sport getSportById(long id) {
				
				//return repo.findById(id).orElse(null);
				
				//or 
				
				Optional<Sport> e= sportRepository.findById(id);
				if(e.isPresent()) {
					return e.get();
				}
				else {
					throw new ResourceNotFoundException("Sport", "id", id);
				}
				//u can use lamda expression also
				
//				return userRepository.findById(id).orElseThrow(() -> 
//				new ResourceNotFoundException("Employee", "id", id));
//				
			}

			@Override
			public Sport updateSport(Sport sport, long id) {
				//first we need to check the user with given id is exist in db or not
				
				Sport existingSport= sportRepository.findById(id).orElseThrow(() -> 
				new ResourceNotFoundException("Sport", "id", id));
				
				existingSport.setSportName(sport.getSportName());
				existingSport.setFees(sport.getFees());
				
				//save existing emp to db
				
				return sportRepository.save(existingSport);
				
			}

			@Override
			public void deleteSport(long sportId) {
				
				//if id not existed we need to throw exception check whether emp exist in db or not
				
//				sportRepository.findById(sportId).orElseThrow(() -> 
//					new ResourceNotFoundException("Sport", "sportId", sportId));
				sportRepository.deleteById(sportId);
				
			}

			
		}




