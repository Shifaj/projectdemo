package com.cybage.service;


	

	import java.util.List;

import org.springframework.stereotype.Service;

import com.cybage.entity.Logs;
@Service

	public interface ILogsService {

	// get all logs
	public List<Logs> getAllLogs();

	// gertAll logs for perticular userid
	public List<Logs> getLogsById(int id);

	// add log
	public void addLog(Logs logs);

	// gertAll logs for perticular userid
	public List<Logs> getLogsByFirstName(String name);

	}

