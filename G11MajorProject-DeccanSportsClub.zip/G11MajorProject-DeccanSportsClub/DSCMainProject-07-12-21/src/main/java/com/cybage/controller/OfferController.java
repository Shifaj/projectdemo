package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.entity.Comment;
import com.cybage.entity.Offer;
import com.cybage.service.CommentService;
import com.cybage.service.OfferService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
//@RequestMapping("admin")
public class OfferController {

	@Autowired
	public OfferService offerService;
	@Autowired
	public CommentService commentService;

	// add offer
	@PostMapping("/addOffer")
	public ResponseEntity<Offer> saveOffer(@RequestBody Offer offer) {

		return new ResponseEntity<Offer>(offerService.saveOffer(offer), HttpStatus.CREATED);
	}

	// get offers
	@GetMapping("/offer")
	public List<Offer> getOffer() {
		return offerService.getOffer();
	}

	// get offer by id
	@GetMapping("/offer/{offerId}")
	public ResponseEntity<Offer> getOfferById(@PathVariable("offerId") long id) {
		return new ResponseEntity<Offer>(offerService.getOfferById(id), HttpStatus.OK);
	}

	// update
	@PutMapping("updateOffer/{offerId}")
	public ResponseEntity<Offer> updateOffer(@PathVariable("offerId") long offerId, @RequestBody Offer offer) {
		return new ResponseEntity<Offer>(offerService.updateOffer(offer, offerId), HttpStatus.OK);

	}

	// delete
	@DeleteMapping("/deleteOffer/{offerId}")
	public ResponseEntity<String> deleteOffer(@PathVariable("offerId") long offerId) {

		// delete offer from db
		offerService.deleteOffer(offerId);
		return new ResponseEntity<String>("Offer deleted successfully!!", HttpStatus.OK);

	}
	
	@PostMapping("/addLike/{offerId}")
	public ResponseEntity<String> addLike(@PathVariable("offerId") long offerId){
		offerService.addLike(offerId);
		return new ResponseEntity<String>("Offer liked!",HttpStatus.OK);
	}
	
	@PostMapping("/removeLike/{offerId}")
	public ResponseEntity<String> removeLike(@PathVariable("offerId") long offerId){
		offerService.removeLike(offerId);
		return new ResponseEntity<String>("Offer disliked!",HttpStatus.OK);
	}

	@GetMapping("/getAllComments")
	public List<Comment> getComments() {
		return commentService.getComments();
	}
	
	@PostMapping("/addComment")
	public ResponseEntity<Comment> addComment(@RequestBody Comment comment) {

		return new ResponseEntity<Comment>(commentService.addComment(comment), HttpStatus.CREATED);
	}
	

}
