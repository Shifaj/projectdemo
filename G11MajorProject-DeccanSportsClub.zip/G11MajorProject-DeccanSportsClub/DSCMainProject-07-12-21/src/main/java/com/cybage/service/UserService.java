package com.cybage.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cybage.entity.User;

@Service
public interface UserService {

	User saveUser(User user);

	List<User> getUser();
	User getUserById(int userId);
	User updateUser(User user,int userId);
	void deleteUser(int userId);
	User approveUser(User user, int id);

	User rejectUser(User user, int id);
	}


