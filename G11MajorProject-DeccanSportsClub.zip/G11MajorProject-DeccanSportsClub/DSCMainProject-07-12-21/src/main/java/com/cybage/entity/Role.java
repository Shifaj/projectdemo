package com.cybage.entity;

public enum Role {
			ADMIN,MANAGER,USER
}
