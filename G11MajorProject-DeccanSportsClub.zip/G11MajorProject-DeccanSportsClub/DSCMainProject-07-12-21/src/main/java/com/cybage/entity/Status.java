package com.cybage.entity;

public enum Status {
					LOCK,UNLOCK
}
