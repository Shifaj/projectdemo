package com.cybage.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity
@Table(name="offer")
public class Offer {
	
		public Offer(long offerId, @NotNull String offerName, @NotNull String offerDescription, int likes,
			@NotNull double discount) {
		super();
		this.offerId = offerId;
		this.offerName = offerName;
		this.offerDescription = offerDescription;
		this.likes = likes;
		this.discount = discount;
	}
					public Offer() {
						super();
					}
					@Id //pK
					@GeneratedValue(strategy=GenerationType.IDENTITY) //pk generation statergy
					private long offerId;
					
					@Column(unique=true)
					@NotNull
					private String offerName;
					
//					@Column(name="startDate")
//					@NotNull
//					private Date startDate ;
//					
//					@Column(name="endDate")
//					@NotNull
//					private Date endDate ;
//					
					@Column(name="offerDescription")
					@NotNull
					private String offerDescription;
					
					@Column(name="likes")
					private int likes;

					
					@Column(name="discount")
					@NotNull
					private double discount;
							
					

					public long getOfferId() {
						return offerId;
					}

					public void setOfferId(long offerId) {
						this.offerId = offerId;
					}

					public String getOfferName() {
						return offerName;
					}

					public void setOfferName(String offerName) {
						this.offerName = offerName;
					}

					public String getOfferDescription() {
						return offerDescription;
					}

					public void setOfferDescription(String offerDescription) {
						this.offerDescription = offerDescription;
					}

					public double getDiscount() {
						return discount;
					}

					public void setDiscount(double discount) {
						this.discount = discount;
					}

					public int getLikes() {
						return likes;
					}

					public void setLikes(int likes) {
						this.likes = likes;
					}

					
					
					
				}




