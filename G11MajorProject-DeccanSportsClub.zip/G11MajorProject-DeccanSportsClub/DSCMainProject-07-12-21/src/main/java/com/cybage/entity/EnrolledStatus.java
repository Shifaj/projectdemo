package com.cybage.entity;

public enum EnrolledStatus {
	APPROVED,REJECTED,PENDING;
}
