package com.cybage.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cybage.entity.Comment;

@Service
public interface CommentService {

	Comment addComment(Comment comment);
	
	List<Comment> getComments();
	
	Comment getCommentById(long commentId);
	
}
