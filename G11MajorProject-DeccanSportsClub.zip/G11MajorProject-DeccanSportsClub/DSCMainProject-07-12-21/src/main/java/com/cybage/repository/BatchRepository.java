package com.cybage.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cybage.entity.Batch;

public interface BatchRepository extends JpaRepository<Batch, Long> {

}
