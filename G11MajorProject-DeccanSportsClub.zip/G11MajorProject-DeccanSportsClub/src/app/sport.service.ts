import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SportService {
  private baseUrl = 'http://localhost:8081/admin';
  constructor(private http: HttpClient) { }
  getSports(): Observable<any> {
    return this.http.get(`${this.baseUrl}/sport`);
  }

  getSport(sportId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/sport/${sportId}`);
  }

  addSport(sport: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/addSport`, sport);
  }

  updateSport(sportId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateSport/${sportId}`, value);
  }

  deleteSport(sportId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteSport/${sportId}`, { responseType: 'text' });
  }
}