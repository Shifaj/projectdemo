
import { Component } from '@angular/core';
 //import {  MatDialogConfig, MatDialogRef } from '@angular/material/config';
import { MatDialog} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { PopupboxComponent } from './components/popupbox/popupbox.component';
import { AuthServiceService } from './service/auth-service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {


  data:any;
  ngOnInit(){
  }
  constructor(private router:Router,private service:AuthServiceService){}

  logOut(){
    sessionStorage.clear();
    localStorage.clear();
    
    this.router.navigate(['/']);
    

  }

  getSession():any{

return this.service.getStorage().length;

  }
}
