import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MembershipService {
  private baseUrl = 'http://localhost:8081';
  constructor(private http: HttpClient) { }

  getMemberships(): Observable<any> {

    return this.http.get(`${this.baseUrl}/getMembership`);
  }

  getMembership(membershipId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getMembership/${membershipId}`);
  }

  addMembership(membership: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/addMembership`, membership);
  }

  updateMembership(membershipId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateMembership/${membershipId}`, value);
  }

  deleteMembership(membershipId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteMembership/${membershipId}`, { responseType: 'text' });
  }

  //-------- Batch methods -----------

  getBatch(batchId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/batch/${batchId}`);
  }

  addBatch(batch: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/addBatches`, batch);
  }

  updateBatch(batchId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateBatch/${batchId}`, value);
  }

  deleteBatch(batchId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteBatch/${batchId}`, { responseType: 'text' });
  }

  getBatchList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/batch`);
  }

  //-------------- offers -----------------

  getOffers(): Observable<any> {
    return this.http.get(`${this.baseUrl}/offer`);
  }

  getOffer(offerId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/offer/${offerId}`);
  }

  addOffer(membership: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/addOffer`, membership);
  }

  updateOffer(offerId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateOffer/${offerId}`, value);
  }

  deleteOffer(offerId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteOffer/${offerId}`, { responseType: 'text' });
  }

  

  //------------- user ---------------
  getUsers(): Observable<any> {
    return this.http.get(`${this.baseUrl}/allUser`);
  }

  /* changePassword(email: string): Observable<any> {
    return this.http.put(`${this.baseUrl}/forgotPassword/${email}`);
  } */

  approveUser(id: number):Observable<any>{
    return this.http.get(`${this.baseUrl}/approveUser/${id}`);
  }

  rejectUser(id: number):Observable<any>{
    return this.http.get(`${this.baseUrl}/rejectUser/${id}`);
  }

  getSports(): Observable<any> {
    return this.http.get(`${'http:localhost:8081/admin'}/sport`);
  }
}
