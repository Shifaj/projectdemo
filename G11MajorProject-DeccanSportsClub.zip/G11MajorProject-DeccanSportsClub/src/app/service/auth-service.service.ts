import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, mapTo, Observable, of, tap } from 'rxjs';
import { User } from 'src/user';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  constructor(private http: HttpClient) {

    let remember = localStorage.getItem("remember_me");
    if (remember == "true") {
      this.rememberMe = true;
    }
    else {
      this.rememberMe = false;
      localStorage.setItem('remember_me', "false");
    }



  }

  private readonly userData = 'userData';
  private loggedUser: any;
  private rememberMe: boolean;

  public loginUserFromRemote(user: User): Observable<any> {
    return this.http.post<any>("http://localhost:8081/admin/login", user).pipe(
      tap(data => {
        this.doLoginUser(user.email, data)
      }),
      mapTo(true),
      catchError(() => {
        return of(false)
      })
    );

  }


  doLoginUser(email: string, data: User) {


    this.loggedUser = email;
    this.storeUserData(data);

  }
  storeUserData(data: User) {
    this.getStorage().setItem(this.userData, JSON.stringify(data))
  }

  getUserData() {
    return JSON.parse(<string>this.getStorage().getItem(this.userData))
  }

  setLoggedInAs(role: string) {
    this.getStorage().setItem('LoggedInAs', role)
  }

  getLoggedInAs(): string | null {
    return this.getStorage().getItem('LoggedInAs');
  }

  verifyOTP(myotp: { otp: any }, email: string): Observable<boolean> {

    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<boolean>("http://localhost:8081/validate/" + email, myotp, httpOptions).pipe(
      mapTo(true),
      catchError(() => {
        return of(false);
      }))

  }
  generateOtp(email: string): Observable<boolean> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<boolean>("http://localhost:8081/generate/" + email, httpOptions).pipe(
      mapTo(true),
      catchError(() => {
        return of(false);
      }))

  }


  setRememberme(rememberMe: boolean): void {
    this.rememberMe = rememberMe;
    if (!rememberMe) {
      localStorage.setItem('remember_me', "false");
    }
    else {
      localStorage.setItem('remember_me', "true");
    }
  }

  getRememberMe(value: boolean) {

    return this.rememberMe = value;
  }

  getStorage(): Storage {
    if (this.rememberMe) {
      return localStorage;
    }
    return sessionStorage;
  }
}
