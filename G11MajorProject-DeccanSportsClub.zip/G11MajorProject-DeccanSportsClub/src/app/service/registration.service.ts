import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, mapTo, Observable, of } from 'rxjs';
import { User } from 'src/user';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  
 // constructor(private http:HttpClient, private router:Router) { }
//  loginUserFromRemote(email:string,password:string){
//    const body={
//      email:email,
//      password:password
// return this.http.post("http://localhost:8081/admin/login",body);

//   }
//    }
  
constructor(private http:HttpClient) { }

  public registerUserFromRemote(user:User):Observable<any>{
    return this.http.post<any>("http://localhost:8081/admin/registerUser",user).pipe(
      mapTo(true),
      catchError(()=>{
          return of(false)
      })
          );
  }
    
    public loginUserFromRemote(user:User):Observable<any>{
  return this.http.post<any>("http://localhost:8081/admin/login",user);
  
  //   }
  //   public registerUserFromRemote(user:User):Observable<any>{
  //     return this.http.post<any>("http://localhost:8081/admin/registerUser",user);
      
  
}
}
