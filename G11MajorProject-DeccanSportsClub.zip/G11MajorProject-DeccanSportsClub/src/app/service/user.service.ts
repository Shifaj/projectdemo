import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl = 'http://localhost:8081/admin';
  constructor(private http:HttpClient) { }

getUser():Observable<any>{
  return this.http.get(`${this.baseUrl}/lockedUserList`);
}
unlockAccount(id:number):Observable<any>
{
     return this.http.get(`${this.baseUrl}/unlock/${id}`);
 }
 
}
