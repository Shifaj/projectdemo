import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OfferServiceService {

  
  private baseUrl = 'http://localhost:8081';
  constructor(private http: HttpClient) { }

  getOffers(): Observable<any> {
    return this.http.get(`${this.baseUrl}/offer`);
  }

  addComment(comment: Object): Observable<Object>{
    return this.http.post(`${this.baseUrl}/addComment`, comment);
  }
  
  like(offerId: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/addLike/${offerId}`, { responseType: 'text' });
  }

  dislike(offerId: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/removeLike/${offerId}`, { responseType: 'text' });
  }

}
