
export class Membership{
    membershipId!:number;
    endDate!:Date;
    isActive!:string;
    startDate!:Date;

    sportId!:number;
    offerId!:number ;
    id!:number;
}