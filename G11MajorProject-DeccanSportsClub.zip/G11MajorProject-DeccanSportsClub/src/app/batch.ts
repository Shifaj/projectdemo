import { Time } from "@angular/common";

export class Batch{
    batchId!:number;
    batchName!:string;
    startTime!:Time;
    endTime!:Time;
    batchSize!:number;
    batchDescription!:string;
    isActive!:void;
    sportId!:any;
}