import { Membership } from './membership';

describe('Membership', () => {
  it('should create an instance', () => {
    expect(new Membership()).toBeTruthy();
  });
});
