export class Sport{
    sportId!:number;
    fees!:string;
    sportName!:string;
    
    getSportId(){
        return this.sportId;
    }
}