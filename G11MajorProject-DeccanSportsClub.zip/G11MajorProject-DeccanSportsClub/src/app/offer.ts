export class Offer{
    offerId!:number;
    discount!:number;
    offerDescription!:string;
    offerName!:string;
    likes!:number;

    getOfferId(){
        return this.offerId;
    }
}