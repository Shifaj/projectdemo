import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginSuccessComponent } from 'src/login-success/login-success.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AddBatchComponent } from './components/batch/add-batch/add-batch.component';
import { UpdateBatchComponent } from './components/batch/update-batch/update-batch.component';
import { ViewBatchesComponent } from './components/batch/view-batches/view-batches.component';
import { ContactusComponent } from './components/contactus/contactus.component';
import { DummyComponent } from './components/dummy/dummy.component';
import { MembershipSuccessComponent } from './components/endUser/membership-success/membership-success.component';
import { TakeMembershipComponent } from './components/endUser/take-membership/take-membership.component';
import { UserBatchesComponent } from './components/endUser/user-batches/user-batches.component';
import { UserOffersComponent } from './components/endUser/user-offers/user-offers.component';
import { UserSportComponent } from './components/endUser/user-sport/user-sport.component';
import { HomeSectionComponent } from './components/home-section/home-section.component';
import { LoginComponent } from './components/login/login.component';
import { ManagerDashboardComponent } from './components/manager-dashboard/manager-dashboard.component';
import { BatchesReportManagerComponent } from './components/manager-report/batches-report-manager/batches-report-manager.component';
import { EnrollmentReportManagerComponent } from './components/manager-report/enrollment-report-manager/enrollment-report-manager.component';
import { SportReportManagerComponent } from './components/manager-report/sport-report-manager/sport-report-manager.component';
import { AddManagerComponent } from './components/manager/add-manager/add-manager.component';
import { UpdateManagerComponent } from './components/manager/update-manager/update-manager.component';
import { ViewManagerComponent } from './components/manager/view-manager/view-manager.component';
import { ViewMembershipComponent } from './components/membership/view-membership/view-membership.component';
import { AddOfferComponent } from './components/offer/add-offer/add-offer.component';
import { UpdateOfferComponent } from './components/offer/update-offer/update-offer.component';
import { ViewOffersComponent } from './components/offer/view-offers/view-offers.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { BatchReportComponent } from './components/reports/batch-report/batch-report.component';
import { SportReportComponent } from './components/reports/sport-report/sport-report.component';
import { UserReportComponent } from './components/reports/user-report/user-report.component';
import { AddSportComponent } from './components/sports/add-sport/add-sport.component';
import { UpdateSportComponent } from './components/sports/update-sport/update-sport.component';
import { ViewSportComponent } from './components/sports/view-sport/view-sport.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { ViewUsersComponent } from './components/users/view-users/view-users.component';
import { VerifyOTPComponent } from './components/verify-otp/verify-otp.component';
import { ViewEnrolledUsersComponent } from './components/view-enrolled-users/view-enrolled-users.component';

const routes: Routes = [
  {path:"",component:HomeSectionComponent},
  {path:'home',component:HomeSectionComponent},
  {path:"loginLink",component:LoginComponent},
  {path:"adminDashboard",component:AdminDashboardComponent},
  {path:"registration",component:RegistrationComponent},

  { path:'addSport', component: AddSportComponent},
 
  { path: 'showSport', component: ViewSportComponent},
  { path: 'updateSport/:id', component: UpdateSportComponent},

  {path :'addUser',component:AddManagerComponent},
  { path: 'showUser', component: ViewManagerComponent},
  { path: 'update/:id', component: UpdateManagerComponent},
  {path:'dummy',component:DummyComponent},
  {path:'lockedUserList',component:ViewUsersComponent },
  {path:"managerDashboard",component:ManagerDashboardComponent},
  { path: 'membership', component: ViewMembershipComponent},
  { path: 'user', component: ViewEnrolledUsersComponent},
  { path:'addOffer', component: AddOfferComponent},
  { path:'addBatch', component: AddBatchComponent},
  { path: 'showBatch', component: ViewBatchesComponent},
  { path: 'showOffer', component: ViewOffersComponent},
  { path: 'updateOffer/:id', component: UpdateOfferComponent},
  { path: 'updateBatch/:id', component: UpdateBatchComponent},
  {path:'enrolledUsersReport',component:UserReportComponent},
  {path:'sportReport',component:SportReportComponent},
  {path:'batchReport',component:BatchReportComponent},
  {path:'userDashboard',component:UserDashboardComponent},
{path:'membershipSuccessful',component:MembershipSuccessComponent},
{path:'gotoBatchList',component:UserBatchesComponent},
{path:'gotoOfferList',component:UserOffersComponent},
{path:'gotoSportList',component:UserSportComponent},
{path:'takeMembership',component:TakeMembershipComponent},
{path:"login/verifyOtp/:email", component:VerifyOTPComponent},
{path:"aboutus",component:AboutusComponent},
{path:"contactus",component:ContactusComponent},
{path:"managerbatchReport",component:BatchesReportManagerComponent},
{path:"managerenrolledUsersReport",component:EnrollmentReportManagerComponent},
{path:"managersportReport",component:SportReportManagerComponent},
  // { path: 'forgotPassword', component: ForgotPasswordComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
