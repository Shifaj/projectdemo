import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import jsPDF from 'jspdf';
import { Observable } from 'rxjs';
import { Sport } from 'src/app/sport';
import { SportService } from 'src/app/sport.service';

@Component({
  selector: 'app-sport-report',
  templateUrl: './sport-report.component.html',
  styleUrls: ['./sport-report.component.scss']
})
export class SportReportComponent implements OnInit {
  @ViewChild('pdfTable',{static:false}) el!:ElementRef;
  makePDF(){
    let pdf=new jsPDF('p','pt','a3');
    pdf.html(this.el.nativeElement,{
      callback:(pdf)=>{
        pdf.save('sportDetails.pdf');
      },
    });
  }
    constructor(private sportService: SportService, private router: Router) { }
    id!:number;
    sport!:Observable<Sport[]>
    ngOnInit(): void {
      this.reloadData();
    }
  
    reloadData(){
      this.sport = this.sportService.getSports();
    }
  
    deleteSport(id: number) {
      this.sportService.deleteSport(id)
        .subscribe(
          data => {
            console.log(data);
            this.reloadData();
          },
          error => console.log(error));
    }
  
    updateSport(id: number){
      this.router.navigate(['updateSport', id]);
    }
  
    addSport(){
      this.router.navigate(['addSport']);
    }
  
  }
  
  