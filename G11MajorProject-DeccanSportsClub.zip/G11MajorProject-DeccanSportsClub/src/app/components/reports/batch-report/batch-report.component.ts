import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import jsPDF from 'jspdf';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-batch-report',
  templateUrl: './batch-report.component.html',
  styleUrls: ['./batch-report.component.scss']
})
export class BatchReportComponent implements OnInit {
  @ViewChild('pdfTable',{static:false}) el!:ElementRef;
  makePDF(){
    let pdf=new jsPDF('p','pt','a3');
    pdf.html(this.el.nativeElement,{
      callback:(pdf)=>{
        pdf.save('BatchDetails.pdf');
      },
    });
  }

  constructor(private membershipService: MembershipService,
    private router: Router) { }
    //batch!:Observable<any[]>;
    batch:any=[];
    sport:any;
  ngOnInit(): void {
    this.membershipService.getBatchList().
    subscribe(data=>
      {this.batch = data;});
  }

  deleteBatch(id: number) {
    this.membershipService.deleteBatch(id)
      .subscribe(
        data => {
          console.log(data);
          this.ngOnInit();
        },
        error => console.log(error));
  }

  updateBatch(id: number){
    this.router.navigate(['updateBatch', id]);
  }

  addBatch(){
    this.router.navigate(['addBatch']);
  }
}
