import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from 'src/app/service/registration.service';
import { User } from 'src/user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  user=new User();
  msg='';
    constructor(private service:RegistrationService,private _router:Router) { }
  
    ngOnInit(): void {
    }
    registerUser(){
      this.service.registerUserFromRemote(this.user).subscribe(
        success=>{
          if(success){
            alert(success);
            this.msg="Registration successful";
            this._router.navigate(["/loginLink"]);
            
          }
          else
                  {
  alert("Registration failed");
                      }

                    })
                  }
                
                }

        //   console.log("response recieved");
        //   this._router.navigate(["/login"]);
        //   this.msg="Registration successful";
        // },
        // error=>{
        //   console.log("exception occured in registration"),
        //   this.msg=error.error;
          
        