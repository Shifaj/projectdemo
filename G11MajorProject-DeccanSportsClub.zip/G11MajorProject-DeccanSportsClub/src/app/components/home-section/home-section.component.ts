import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog'
import { LoginComponent } from '../login/login.component';
import { RegistrationComponent } from '../registration/registration.component';

@Component({
  selector: 'app-home-section',
  templateUrl: './home-section.component.html',
  styleUrls: ['./home-section.component.scss']
})
export class HomeSectionComponent implements OnInit {

  constructor(private dialogue:MatDialog){}
  openDialog(){
    this.dialogue.open(RegistrationComponent,{ height: '30rem',
         width: '25rem'})
  }
  // openDialogLogin(){
  //   this.dialogue.open(LoginComponent,{ height: '30rem',
  //        width: '25rem'})
  // }

  ngOnInit(): void {
  }

}
