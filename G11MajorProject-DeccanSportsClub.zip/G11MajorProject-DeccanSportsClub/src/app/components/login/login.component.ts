import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceService } from 'src/app/service/auth-service.service';

import { RegistrationService } from 'src/app/service/registration.service';
import { User } from 'src/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {



  user = new User();
  rememberMe: boolean = false;
  msg = '';

  loggedRole: any;
  email: any;

  constructor(private service: AuthServiceService, private _router: Router) {


  }

  ngOnInit(): void {}


  loginUser() {
    this.service.loginUserFromRemote(this.user).subscribe(
      success => {
        if (success) {

          //console.log(this.service.getUserData().role);
          this.loggedRole = this.service.getUserData().role;
          this.email = this.service.getUserData().email;
          //console.log(this.loggedRole);

          if (this.loggedRole.match("USER")) {
            this.service.generateOtp(this.email).subscribe(
              success => {
                if (success) {
                  this._router.navigate(['/login/verifyOtp/' + this.email])
                }
                else {
                  alert("Server error");
                }
              }
            )
          }
          else if (this.loggedRole.match("ADMIN")) {
            this._router.navigate(['/adminDashboard']);
          }
          else {
            this._router.navigate(['/managerDashboard']);
          }
        }
        else{
          console.log("exception occured");
            this.msg="Bad Credentials, please enter valid email or password";
        }
      }
        
    );
  }



  rememmmberMe(event: any) {
    if (event.target.checked) {
      this.rememberMe = true;
      this.service.getRememberMe(this.rememberMe)

    }
    else {

      this.rememberMe = false;

      this.service.getRememberMe(this.rememberMe)

    }

  }

}
