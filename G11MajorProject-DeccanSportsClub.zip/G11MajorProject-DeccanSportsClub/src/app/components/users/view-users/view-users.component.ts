import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from 'src/app/service/user.service';
import { User } from 'src/user';

@Component({
  selector: 'app-view-users',
  templateUrl: './view-users.component.html',
  styleUrls: ['./view-users.component.scss']
})
export class ViewUsersComponent implements OnInit {

  constructor(private userService:UserService, private router:Router) { }
id!:number;
user:any=[];
//user!:Observable<User[]>
  ngOnInit(): void {
    this.reloadData();
  }
  reloadData(){
    this.userService.getUser().subscribe(data=>{
       this.user=data;
    });
  }
unlockAccount(id: number){
  this.userService.unlockAccount(id)
  .subscribe(data => {
    this.ngOnInit();
    console.log(data);
    this.gotoList();
  },error => console.log(error));
}
gotoList(){
  this.router.navigate(['/lockedUserList']);
}
}
