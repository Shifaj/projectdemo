import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-view-membership',
  templateUrl: './view-membership.component.html',
  styleUrls: ['./view-membership.component.scss']
})
export class ViewMembershipComponent implements OnInit {

  constructor(private membershipService: MembershipService, private router: Router) { }
  membership:any = [];
  ngOnInit(): void {
    this.membershipService.getMemberships().
    subscribe(data=>
      {this.membership = data;});
  }

 /*  reloadData(){
    this.membership = this.membershipService.getMemberships();
  } */
}