import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popupbox',
  templateUrl: './popupbox.component.html',
  styleUrls: ['./popupbox.component.scss']
})
export class PopupboxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
