import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import jsPDF from 'jspdf';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-view-enrolled-users',
  templateUrl: './view-enrolled-users.component.html',
  styleUrls: ['./view-enrolled-users.component.scss']
})
export class ViewEnrolledUsersComponent implements OnInit {

  @ViewChild('pdfTable',{static:false}) el!:ElementRef;
makePDF(){
  let pdf=new jsPDF('p','pt','a3');
  pdf.html(this.el.nativeElement,{
    callback:(pdf)=>{
      pdf.save('EnrolledUserDetails.pdf');
    },
  });
}

  constructor(private membershipService: MembershipService, private router: Router) { }
  id!:number;
  user:any=[];
  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.membershipService.getUsers().
    subscribe(data=>{
      this.user = data;
    });
  }

  approveUser(id: number) {
    this.membershipService.approveUser(id)
      .subscribe(data => {
        this.ngOnInit();
        console.log(data);
        //this.gotoList();
      }, error => console.log(error));
  }

  rejectUser(id: number) {
    this.membershipService.rejectUser(id)
      .subscribe(data => {
        this.ngOnInit();
        console.log(data);
        //this.gotoList();
      }, error => console.log(error));
  }

  gotoList() {
    this.router.navigate(['/user']);
  }
}
