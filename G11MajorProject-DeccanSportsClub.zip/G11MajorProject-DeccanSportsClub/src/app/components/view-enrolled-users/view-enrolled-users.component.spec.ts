import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEnrolledUsersComponent } from './view-enrolled-users.component';

describe('ViewEnrolledUsersComponent', () => {
  let component: ViewEnrolledUsersComponent;
  let fixture: ComponentFixture<ViewEnrolledUsersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewEnrolledUsersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewEnrolledUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
