import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SportService } from 'src/app/sport.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  constructor(private service:SportService,private _router:Router) { }

  ngOnInit(): void {
  }

  gotoManagerList(){
    
    this._router.navigate(["/showUser"])
  }
  gotoSportList(){

    this._router.navigate(["/showSport"])
  }
  gotoUnlockList(){
    this._router.navigate(["/lockedUserList"]);
  }
  gotoEnrolledReport(){

    this._router.navigate(["/enrolledUsersReport"])
  }
  gotoBatchReport(){

    this._router.navigate(["/batchReport"])
  }

  gotoSportReport(){

    this._router.navigate(["/sportReport"])
  }
}
