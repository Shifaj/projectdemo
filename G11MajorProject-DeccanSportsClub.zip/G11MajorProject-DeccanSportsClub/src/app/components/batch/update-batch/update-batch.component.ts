import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Batch } from 'src/app/batch';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-update-batch',
  templateUrl: './update-batch.component.html',
  styleUrls: ['./update-batch.component.scss']
})
export class UpdateBatchComponent implements OnInit {

  id!:number;
  batch!:Batch;
  submitted = false;
  batchUpdate:any;
  constructor(private route: ActivatedRoute,private router: Router,
    private membershipService: MembershipService) { }

    ngOnInit() {
      this.id = this.route.snapshot.params['id'];
      
      this.membershipService.getBatch(this.id)
        .subscribe(data => {
          console.log(data)
          this.batch = data;
        }, error => console.log(error));

        this.batchUpdate = new FormGroup({
          batchName: new FormControl(''),
          batchDescription: new FormControl(''),
          startTime: new FormControl(''),
          endTime: new FormControl(''),
          batchSize: new FormControl(''),
          sportId: new FormControl(0),
        });
    }
  
    updateBatch() {
      this.membershipService.updateBatch(this.id, this.batchUpdate.value)
        .subscribe(data => {
          console.log(data);
          this.batch = new Batch();
          this.gotoList();
        }, error => console.log(error));
    }
  
    onSubmit() {
      this.updateBatch();    
    }
  
    gotoList() {
      this.router.navigate(['/showBatch']);
    }

}

