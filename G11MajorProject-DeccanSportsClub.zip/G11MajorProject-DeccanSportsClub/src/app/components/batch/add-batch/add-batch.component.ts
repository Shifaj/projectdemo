import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Batch } from 'src/app/batch';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-add-batch',
  templateUrl: './add-batch.component.html',
  styleUrls: ['./add-batch.component.scss']
})
export class AddBatchComponent implements OnInit {
  batch: Batch = new Batch();
  submitted = false;
  constructor(private membershipService: MembershipService, private router: Router) { }
  addBatch:any;
  sports:any=[];
  ngOnInit(): void {
    this.addBatch = new FormGroup({
      batchName: new FormControl(''),
      batchDescription: new FormControl(''),
      startTime: new FormControl(''),
      endTime: new FormControl(''),
      batchSize: new FormControl(''),
      sportId: new FormControl(0),
      sportsName: new FormControl(''),
    });
    this.sports = this.getSports();
  }

  getSports(){
    this.membershipService.getSports().subscribe(res=>{
      console.log(res);
    });
  }

  newBatch(): void {
    this.submitted = false;
    this.batch = new Batch();
  }

  save() {
    console.log(this.addBatch.value);
    this.membershipService
    .addBatch(this.addBatch.value).subscribe(data => {
      
      this.batch = new Batch();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/showBatch']);
  }
}
