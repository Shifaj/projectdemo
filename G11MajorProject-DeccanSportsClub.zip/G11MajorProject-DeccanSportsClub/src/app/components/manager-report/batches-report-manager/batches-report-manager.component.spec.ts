import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchesReportManagerComponent } from './batches-report-manager.component';

describe('BatchesReportManagerComponent', () => {
  let component: BatchesReportManagerComponent;
  let fixture: ComponentFixture<BatchesReportManagerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BatchesReportManagerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchesReportManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
