import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SportReportManagerComponent } from './sport-report-manager.component';

describe('SportReportManagerComponent', () => {
  let component: SportReportManagerComponent;
  let fixture: ComponentFixture<SportReportManagerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SportReportManagerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SportReportManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
