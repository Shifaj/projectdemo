import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnrollmentReportManagerComponent } from './enrollment-report-manager.component';

describe('EnrollmentReportManagerComponent', () => {
  let component: EnrollmentReportManagerComponent;
  let fixture: ComponentFixture<EnrollmentReportManagerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnrollmentReportManagerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnrollmentReportManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
