import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Sport } from 'src/app/sport';
import { SportService } from 'src/app/sport.service';

@Component({
  selector: 'app-add-sport',
  templateUrl: './add-sport.component.html',
  styleUrls: ['./add-sport.component.scss']
})
export class AddSportComponent implements OnInit {

sport: Sport = new Sport();
  submitted = false;

  constructor(private sportService:SportService,
    private router: Router) { }

  ngOnInit(): void {
  }

  newsport(): void {
    this.submitted = false;
    this.sport = new Sport();
  }

  save() {
    this.sportService
    .addSport(this.sport).subscribe(data => {
      console.log(data)
      this.sport = new Sport();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/showSport']);
  }

}

