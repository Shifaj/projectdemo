import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Sport } from 'src/app/sport';
import { SportService } from 'src/app/sport.service';

@Component({
  selector: 'app-update-sport',
  templateUrl: './update-sport.component.html',
  styleUrls: ['./update-sport.component.scss']
})
export class UpdateSportComponent implements OnInit {

  id!:number;
  sport!:Sport;

  constructor(private route: ActivatedRoute,private router: Router,
    private sportService: SportService) { }

    ngOnInit() {
      this.sport = new Sport();
  
      this.id = this.route.snapshot.params['id'];
      
      this.sportService.getSport(this.id)
        .subscribe(data => {
          console.log(data)
          this.sport = data;
        }, error => console.log(error));
    }
  
    updateSport() {
      this.sportService.updateSport(this.id, this.sport)
        .subscribe(data => {
          console.log(data);
          this.sport = new Sport();
          this.gotoList();
        }, error => console.log(error));
    }
  
    onSubmit() {
      this.updateSport();    
    }
  
    gotoList() {
      this.router.navigate(['/showSport']);
    }

}
