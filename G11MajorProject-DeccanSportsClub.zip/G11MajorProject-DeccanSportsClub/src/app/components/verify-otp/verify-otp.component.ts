import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServiceService } from 'src/app/service/auth-service.service';
import { RegistrationService } from 'src/app/service/registration.service';

@Component({
  selector: 'app-verify-otp',
  templateUrl: './verify-otp.component.html',
  styleUrls: ['./verify-otp.component.scss']
})
export class VerifyOTPComponent implements OnInit {


  email:any
  data1:any
  constructor(private service: AuthServiceService, private formBuilder: FormBuilder, private activatedRoute: ActivatedRoute, private route : Router) {
    this.activatedRoute.params.subscribe((data) =>{
      this.email = data;
      this.data1 = this.email.email
    })
   }


  verifyOTPform:any;
  ngOnInit(): void {
   this.verifyOTPform = this.formBuilder.group({
    otp: ["",[Validators.required]]
   })

  }

  get f(){
    return this.verifyOTPform.controls;
  }
  verifyOTp(){
        this.service.verifyOTP({otp: this.f.otp.value},this.data1).subscribe((success) =>{
          if(success){
            alert("otp Verified")
            this.route.navigate(['/userDashboard']);
          }

          else{
            // this.route.navigate(['/loginLink'])
            alert("Entered OTP Is incorrect please try again")
            window.location.reload();
          }
        }) 
  }
}
