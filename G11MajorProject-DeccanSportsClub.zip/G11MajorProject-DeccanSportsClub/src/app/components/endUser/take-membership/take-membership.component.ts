import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Membership } from 'src/app/membership';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-take-membership',
  templateUrl: './take-membership.component.html',
  styleUrls: ['./take-membership.component.scss']
})
export class TakeMembershipComponent implements OnInit {

  constructor(private membershipService: MembershipService,
    private router: Router) { }

    membership: Membership = new Membership();
    submitted = false;
    membershipNew:any ;

  ngOnInit(): void {
    this.membershipNew = new FormGroup({
      endDate : new FormControl(''),
      sportId : new FormControl(),
      offerId : new FormControl(),
      userId : new FormControl(),
    });
  }

  newMembership(): void {
    this.submitted = false;
    this.membership = new Membership();
  }

  save() {
    this.membershipService
    .addMembership(this.membershipNew.value).subscribe(data => {
      this.membership = new Membership();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/membershipSuccessful']);
  }

}
