import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Sport } from 'src/app/sport';
import { SportService } from 'src/app/sport.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-user-sport',
  templateUrl: './user-sport.component.html',
  styleUrls: ['./user-sport.component.scss']
})
export class UserSportComponent implements OnInit {

  constructor(private sportService: SportService, private router: Router,
    private modalService: NgbModal) { }

  id!:number;
  sport!:Observable<Sport[]>
  closeResult = '';
  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.sport = this.sportService.getSports();
  }

}