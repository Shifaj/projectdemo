import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSportComponent } from './user-sport.component';

describe('UserSportComponent', () => {
  let component: UserSportComponent;
  let fixture: ComponentFixture<UserSportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserSportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
