import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserBatchesComponent } from './user-batches.component';

describe('UserBatchesComponent', () => {
  let component: UserBatchesComponent;
  let fixture: ComponentFixture<UserBatchesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserBatchesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserBatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
