import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-user-batches',
  templateUrl: './user-batches.component.html',
  styleUrls: ['./user-batches.component.scss']
})
export class UserBatchesComponent implements OnInit {

  constructor(private batchService: MembershipService,
    private router: Router) { }

    batch: any = [];
    sport:any;
  ngOnInit(): void {
    this.batchService.getBatchList().
    subscribe(data=>
      {this.batch = data;});
  }

}
