import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { OfferServiceService } from 'src/app/service/offer-service.service';
import { NgbModal,ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-user-offers',
  templateUrl: './user-offers.component.html',
  styleUrls: ['./user-offers.component.scss']
})
export class UserOffersComponent implements OnInit {

  constructor(private offerService: OfferServiceService,  private router: Router,
    private modalService: NgbModal) { }

  id!:number;
  offer!:any;
  comment: Comment = new Comment();
  closeResult = '';
  commentAdd:any;
  ngOnInit(): void {
    this.reloadData();
    this.commentAdd = new FormGroup({
      content: new FormControl(''),
     id: new FormControl(),
      offerId: new FormControl(),
    });
  }

  reloadData(){
    this.offerService.getOffers().
    subscribe(data=>{
      this.offer = data;
    });
  }

  addComment() {
    this.offerService
    .addComment(this.commentAdd.value).subscribe(data => {
      this.comment = new Comment();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  addLike(id: number) {
    this.offerService.like(id)
      .subscribe(
        data => {
          this.ngOnInit();
          console.log(data);
        },
        error => console.log(error));
  }

  removeLike(id: number) {
    this.offerService.dislike(id)
      .subscribe(
        data => {
          this.gotoList();
          console.log(data);
        },
        error => console.log(error));
  }

  onSubmit() {
    this.addComment();    
  }

  gotoList() {
    this.router.navigate(['/gotoOfferList']);
  }

  open(content:any) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      /* this.closeResult = `Closed with: ${result}`; */
    }, (reason) => {
      /* this.closeResult = `Dismissed ${this.getDismissReason(reason)}`; */
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}
