import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Offer } from 'src/app/offer';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-update-offer',
  templateUrl: './update-offer.component.html',
  styleUrls: ['./update-offer.component.scss']
})
export class UpdateOfferComponent implements OnInit {
  id!:number;
  offer!:Offer;
  content:any;

  constructor(private route: ActivatedRoute,private router: Router,
    private membershipService: MembershipService) { }

    ngOnInit() {
      this.offer = new Offer();
  
      this.id = this.route.snapshot.params['id'];
      
      this.membershipService.getOffer(this.id)
        .subscribe(data => {
          console.log(data)
          this.offer = data;
        }, error => console.log(error));
    }
  
    updateOffer() {
      this.membershipService.updateOffer(this.id, this.offer)
        .subscribe(data => {
          console.log(data);
          this.offer = new Offer();
          this.gotoList();
        }, error => console.log(error));
    }
  
    onSubmit() {
      this.updateOffer();    
    }
  
    gotoList() {
     
      this.router.navigate(['/showOffer']);
    }

    
}
