import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Offer } from 'src/app/offer';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-add-offer',
  templateUrl: './add-offer.component.html',
  styleUrls: ['./add-offer.component.scss']
})
export class AddOfferComponent implements OnInit {

  offer: Offer = new Offer();
  submitted = false;

  constructor(private membershipService: MembershipService,
    private router: Router) { }

  ngOnInit(): void {
  }

  newOffer(): void {
    this.submitted = false;
    this.offer = new Offer();
  }

  save() {
    this.membershipService
    .addOffer(this.offer).subscribe(data => {
      console.log(data)
      this.offer = new Offer();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/showOffer']);
  }

}
