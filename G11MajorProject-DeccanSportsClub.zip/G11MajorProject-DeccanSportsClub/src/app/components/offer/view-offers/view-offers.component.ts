import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Offer } from 'src/app/offer';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-view-offers',
  templateUrl: './view-offers.component.html',
  styleUrls: ['./view-offers.component.scss']
})
export class ViewOffersComponent implements OnInit {
  constructor(private membershipService: MembershipService, private router: Router) { }
  id!:number;
  offer!:Observable<Offer[]>
  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.offer = this.membershipService.getOffers();
  }

  deleteOffer(id: number) {
    this.membershipService.deleteOffer(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  updateOffer(id: number){
    this.router.navigate(['updateOffer', id]);
  }

  addOffer(){
    this.router.navigate(['addOffer']);
  }

}

