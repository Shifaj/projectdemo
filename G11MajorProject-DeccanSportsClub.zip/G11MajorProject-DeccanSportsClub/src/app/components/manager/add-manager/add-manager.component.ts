import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManagerService } from 'src/app/service/manager.service';
import { User } from 'src/user';

@Component({
  selector: 'app-add-manager',
  templateUrl: './add-manager.component.html',
  styleUrls: ['./add-manager.component.scss']
})
export class AddManagerComponent implements OnInit {

 user: User = new User();
  submitted = false;

  constructor(private managerService:ManagerService,
    private router: Router) { }

  ngOnInit(): void {
  }

  newuser(): void {
    this.submitted = false;
    this.user = new User();
  }

  save() {
    this.managerService
    .addUser(this.user).subscribe(data => {
      console.log(data)
      this.user = new User();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }
  
    // this.managerService.addManagerFromRemote(this.user).subscribe(
    //   data=>{
    //     console.log("response recieved");
    //     this.router.navigate(["/showUser"]);
    //     this.msg="Registration successful";
    //   },
    //   error=>{
    //     console.log("exception occured in registration"),
    //     this.msg=error.error;
        
    //   }
    // )
//  }

  gotoList() {
    this.router.navigate(['/showUser']);
  }

}

