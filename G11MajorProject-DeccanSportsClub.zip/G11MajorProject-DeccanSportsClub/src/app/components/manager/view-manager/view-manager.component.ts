import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ManagerService } from 'src/app/service/manager.service';
import { User } from 'src/user';

@Component({
  selector: 'app-view-manager',
  templateUrl: './view-manager.component.html',
  styleUrls: ['./view-manager.component.scss']
})
export class ViewManagerComponent implements OnInit {

  constructor(private managerService: ManagerService, private router: Router) { }
  id!:number;
  user!:Observable<User[]>
  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.user = this.managerService.getUsers();
  }

  deleteUser(id: number) {
    this.managerService.deleteUser(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  updateUser(id: number){
    this.router.navigate(['update', id]);
  }

  addUser(){
    this.router.navigate(['addUser']);
  }

}

