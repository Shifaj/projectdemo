import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MembershipService } from 'src/app/service/membership.service';

@Component({
  selector: 'app-manager-dashboard',
  templateUrl: './manager-dashboard.component.html',
  styleUrls: ['./manager-dashboard.component.scss']
})
export class ManagerDashboardComponent implements OnInit {

  constructor(private service: MembershipService, private _router: Router) { }

  ngOnInit(): void {
  }

  showUsers(){
    this._router.navigate(["/user"]);
  }

  showMemberships(){
    this._router.navigate(["/membership"]);
  }

  showBatches(){
    this._router.navigate(["/showBatch"]);
  }

  showOffers(){
    this._router.navigate(["/showOffer"]);
  }
  gotoManagerEnrolledReport(){

    this._router.navigate(["/managerenrolledUsersReport"])
  }
  gotoBatchManagerReport(){

    this._router.navigate(["/managerbatchReport"])
  }

  gotoSportManagerReport(){

    this._router.navigate(["/managersportReport"])
  }

  // changePassword(){
  //   this._router.navigate(["/forgotPassword"]);
  // }

}
