import { NgModule } from '@angular/core';
import { MatButtonModule }  from '@angular/material/button';

const  MaterislComponents=[ MatButtonModule]


@NgModule({
  
  imports: [ MatButtonModule] ,
  exports:[ MatButtonModule]
})
export class MaterialModule { }
