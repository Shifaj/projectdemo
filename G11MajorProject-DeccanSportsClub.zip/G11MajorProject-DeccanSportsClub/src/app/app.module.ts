import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RegistrationComponent } from './components/registration/registration.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { NavbarComponent } from './components/navbar/navbar.component';
//import { MatSliderModule } from '@angular/material/slider';
import { MatToolbarModule } from '@angular/material/toolbar'
import { MatIconModule } from '@angular/material/icon';
import { DummyComponent } from './components/dummy/dummy.component';
import { GalleryComponent } from './gallery/gallery.component'
import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { HttpClientModule } from '@angular/common/http';
import 'hammerjs';
import { HomeSectionComponent } from './components/home-section/home-section.component';
import { MatDialogModule } from '@angular/material/dialog';
import { PopupboxComponent } from './components/popupbox/popupbox.component';
import { LoginComponent } from './components/login/login.component';

import { MatFormFieldModule } from '@angular/material/form-field';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatListModule} from '@angular/material/list';
import{MatRadioModule} from '@angular/material/radio';
import { AddSportComponent } from './components/sports/add-sport/add-sport.component';
import { ViewSportComponent } from './components/sports/view-sport/view-sport.component';
import { UpdateSportComponent } from './components/sports/update-sport/update-sport.component';
import { AddManagerComponent } from './components/manager/add-manager/add-manager.component';
import { UpdateManagerComponent } from './components/manager/update-manager/update-manager.component';
import { ViewManagerComponent } from './components/manager/view-manager/view-manager.component';
import { ViewUsersComponent } from './components/users/view-users/view-users.component';
import { AddBatchComponent } from './components/batch/add-batch/add-batch.component';
import { UpdateBatchComponent } from './components/batch/update-batch/update-batch.component';
import { ViewBatchesComponent } from './components/batch/view-batches/view-batches.component';
import { UpdateOfferComponent } from './components/offer/update-offer/update-offer.component';
import { ViewOffersComponent } from './components/offer/view-offers/view-offers.component';
import { ViewMembershipComponent } from './components/membership/view-membership/view-membership.component';
import { ManagerDashboardComponent } from './components/manager-dashboard/manager-dashboard.component';
import { ViewEnrolledUsersComponent } from './components/view-enrolled-users/view-enrolled-users.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddOfferComponent } from './components/offer/add-offer/add-offer.component';
import { BodySectionComponent } from './components/body-section/body-section.component';
import { MdbAccordionModule } from 'mdb-angular-ui-kit/accordion';
import { MdbCarouselModule } from 'mdb-angular-ui-kit/carousel';
import { MdbCheckboxModule } from 'mdb-angular-ui-kit/checkbox';
import { MdbCollapseModule } from 'mdb-angular-ui-kit/collapse';
import { MdbDropdownModule } from 'mdb-angular-ui-kit/dropdown';
import { MdbFormsModule } from 'mdb-angular-ui-kit/forms';
import { MdbModalModule } from 'mdb-angular-ui-kit/modal';
import { MdbPopoverModule } from 'mdb-angular-ui-kit/popover';
import { MdbRadioModule } from 'mdb-angular-ui-kit/radio';
import { MdbRangeModule } from 'mdb-angular-ui-kit/range';
import { MdbRippleModule } from 'mdb-angular-ui-kit/ripple';
import { MdbScrollspyModule } from 'mdb-angular-ui-kit/scrollspy';
import { MdbTabsModule } from 'mdb-angular-ui-kit/tabs';
import { MdbTooltipModule } from 'mdb-angular-ui-kit/tooltip';
import { MdbValidationModule } from 'mdb-angular-ui-kit/validation';
import { FooterComponent } from './components/footer/footer.component';
import { UserReportComponent } from './components/reports/user-report/user-report.component';
import { BatchReportComponent } from './components/reports/batch-report/batch-report.component';
import { SportReportComponent } from './components/reports/sport-report/sport-report.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { LoginNavComponent } from './components/login-nav/login-nav.component';
import { UserBatchesComponent } from './components/endUser/user-batches/user-batches.component';
import { UserSportComponent } from './components/endUser/user-sport/user-sport.component';
import { UserOffersComponent } from './components/endUser/user-offers/user-offers.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { MembershipSuccessComponent } from './components/endUser/membership-success/membership-success.component';
import { VerifyOTPComponent } from './components/verify-otp/verify-otp.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { ContactusComponent } from './components/contactus/contactus.component';
import { EnrollmentReportManagerComponent } from './components/manager-report/enrollment-report-manager/enrollment-report-manager.component';
import { SportReportManagerComponent } from './components/manager-report/sport-report-manager/sport-report-manager.component';
import { BatchesReportManagerComponent } from './components/manager-report/batches-report-manager/batches-report-manager.component';




@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    DummyComponent,
    GalleryComponent,
    HomeSectionComponent,
    PopupboxComponent,
    RegistrationComponent,
    LoginComponent,
    AdminDashboardComponent,
    AddSportComponent,
    ViewSportComponent,
    UpdateSportComponent,
    AddManagerComponent,
    UpdateManagerComponent,
    ViewManagerComponent,
    ViewUsersComponent,
    AddBatchComponent,
    UpdateBatchComponent,
    ViewBatchesComponent,
    UpdateOfferComponent,
    ViewOffersComponent,
    ViewMembershipComponent,
    ManagerDashboardComponent,
    ViewEnrolledUsersComponent,
    AddOfferComponent,
    BodySectionComponent,
    FooterComponent,
    UserReportComponent,
    BatchReportComponent,
    SportReportComponent,
    UserDashboardComponent,
    LoginNavComponent,
    UserBatchesComponent,
    UserSportComponent,
    UserOffersComponent,
    MembershipSuccessComponent,
   VerifyOTPComponent,
   AboutusComponent,
   ContactusComponent,
   EnrollmentReportManagerComponent,
   SportReportManagerComponent,
   BatchesReportManagerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    MatToolbarModule,
    MatIconModule,
    MatTabsModule,
    HttpClientModule,
    MatCardModule,
    MatDialogModule,
    FormsModule,
    MatFormFieldModule,
    MatSidenavModule,
    MatListModule,
    MatRadioModule,
    ReactiveFormsModule,
    MdbAccordionModule,
    MdbCarouselModule,
    MdbCheckboxModule,
    MdbCollapseModule,
    MdbDropdownModule,
    MdbFormsModule,
    MdbModalModule,
    MdbPopoverModule,
    MdbRadioModule,
    MdbRangeModule,
    MdbRippleModule,
    MdbScrollspyModule,
    MdbTabsModule,
    MdbTooltipModule,
    MdbValidationModule,
    NgbModule
   
    

    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
