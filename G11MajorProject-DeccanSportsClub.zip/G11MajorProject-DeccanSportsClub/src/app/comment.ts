export class Comment {
    commentId!:number;
    content!:string;
    createdAt!:Date;
    id!:number;
    offerId!:number;
}
