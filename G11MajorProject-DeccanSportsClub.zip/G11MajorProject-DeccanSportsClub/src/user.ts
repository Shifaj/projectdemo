export class User {
    id!: number;
firstName!: string;
lastName!: string;
email!: string;
password!: string;
gender!: string;
role !: string;
status!: string;
enrolledStatus!:string;
loginAttempt!: number;



    // constructor( id: number, email:string, userName:string, password:string){
    //     this.id=id;
    //     this.email=email;
    //     this.userName=userName;
    //     this.password=password;
    // }
    constructor(){}
    getUserId(){
        return this.id;
    }
}


